// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package projet_talend_2023.import_donnee_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: import_donnee Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class import_donnee implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "import_donnee";
	private final String projectName = "PROJET_TALEND_2023";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					import_donnee.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(import_donnee.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_4_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_5_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_6_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String name;

		public String getName() {
			return this.name;
		}

		public Integer host_id;

		public Integer getHost_id() {
			return this.host_id;
		}

		public String host_name;

		public String getHost_name() {
			return this.host_name;
		}

		public String neighbourhood_group;

		public String getNeighbourhood_group() {
			return this.neighbourhood_group;
		}

		public String neighbourhood;

		public String getNeighbourhood() {
			return this.neighbourhood;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String room_type;

		public String getRoom_type() {
			return this.room_type;
		}

		public String price;

		public String getPrice() {
			return this.price;
		}

		public Double minimum_nights;

		public Double getMinimum_nights() {
			return this.minimum_nights;
		}

		public String number_of_reviews;

		public String getNumber_of_reviews() {
			return this.number_of_reviews;
		}

		public String last_review;

		public String getLast_review() {
			return this.last_review;
		}

		public String reviews_per_month;

		public String getReviews_per_month() {
			return this.reviews_per_month;
		}

		public Float calculated_host_listings_count;

		public Float getCalculated_host_listings_count() {
			return this.calculated_host_listings_count;
		}

		public String availability_365;

		public String getAvailability_365() {
			return this.availability_365;
		}

		public Integer CAMIS;

		public Integer getCAMIS() {
			return this.CAMIS;
		}

		public String DBA;

		public String getDBA() {
			return this.DBA;
		}

		public String BORO;

		public String getBORO() {
			return this.BORO;
		}

		public String BUILDING;

		public String getBUILDING() {
			return this.BUILDING;
		}

		public String STREET;

		public String getSTREET() {
			return this.STREET;
		}

		public String ZIPCODE;

		public String getZIPCODE() {
			return this.ZIPCODE;
		}

		public Long PHONE;

		public Long getPHONE() {
			return this.PHONE;
		}

		public String CUISINE_DESCRIPTION;

		public String getCUISINE_DESCRIPTION() {
			return this.CUISINE_DESCRIPTION;
		}

		public String INSPECTION_DATE;

		public String getINSPECTION_DATE() {
			return this.INSPECTION_DATE;
		}

		public String ACTION;

		public String getACTION() {
			return this.ACTION;
		}

		public String VIOLATION_CODE;

		public String getVIOLATION_CODE() {
			return this.VIOLATION_CODE;
		}

		public String VIOLATION_DESCRIPTION;

		public String getVIOLATION_DESCRIPTION() {
			return this.VIOLATION_DESCRIPTION;
		}

		public String CRITICAL_FLAG;

		public String getCRITICAL_FLAG() {
			return this.CRITICAL_FLAG;
		}

		public String SCORE;

		public String getSCORE() {
			return this.SCORE;
		}

		public String GRADE;

		public String getGRADE() {
			return this.GRADE;
		}

		public String GRADE_DATE;

		public String getGRADE_DATE() {
			return this.GRADE_DATE;
		}

		public String RECORD_DATE;

		public String getRECORD_DATE() {
			return this.RECORD_DATE;
		}

		public String INSPECTION_TYPE;

		public String getINSPECTION_TYPE() {
			return this.INSPECTION_TYPE;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

					this.CAMIS = readInteger(dis);

					this.DBA = readString(dis);

					this.BORO = readString(dis);

					this.BUILDING = readString(dis);

					this.STREET = readString(dis);

					this.ZIPCODE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PHONE = null;
					} else {
						this.PHONE = dis.readLong();
					}

					this.CUISINE_DESCRIPTION = readString(dis);

					this.INSPECTION_DATE = readString(dis);

					this.ACTION = readString(dis);

					this.VIOLATION_CODE = readString(dis);

					this.VIOLATION_DESCRIPTION = readString(dis);

					this.CRITICAL_FLAG = readString(dis);

					this.SCORE = readString(dis);

					this.GRADE = readString(dis);

					this.GRADE_DATE = readString(dis);

					this.RECORD_DATE = readString(dis);

					this.INSPECTION_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

					this.CAMIS = readInteger(dis);

					this.DBA = readString(dis);

					this.BORO = readString(dis);

					this.BUILDING = readString(dis);

					this.STREET = readString(dis);

					this.ZIPCODE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PHONE = null;
					} else {
						this.PHONE = dis.readLong();
					}

					this.CUISINE_DESCRIPTION = readString(dis);

					this.INSPECTION_DATE = readString(dis);

					this.ACTION = readString(dis);

					this.VIOLATION_CODE = readString(dis);

					this.VIOLATION_DESCRIPTION = readString(dis);

					this.CRITICAL_FLAG = readString(dis);

					this.SCORE = readString(dis);

					this.GRADE = readString(dis);

					this.GRADE_DATE = readString(dis);

					this.RECORD_DATE = readString(dis);

					this.INSPECTION_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

				// Integer

				writeInteger(this.CAMIS, dos);

				// String

				writeString(this.DBA, dos);

				// String

				writeString(this.BORO, dos);

				// String

				writeString(this.BUILDING, dos);

				// String

				writeString(this.STREET, dos);

				// String

				writeString(this.ZIPCODE, dos);

				// Long

				if (this.PHONE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.PHONE);
				}

				// String

				writeString(this.CUISINE_DESCRIPTION, dos);

				// String

				writeString(this.INSPECTION_DATE, dos);

				// String

				writeString(this.ACTION, dos);

				// String

				writeString(this.VIOLATION_CODE, dos);

				// String

				writeString(this.VIOLATION_DESCRIPTION, dos);

				// String

				writeString(this.CRITICAL_FLAG, dos);

				// String

				writeString(this.SCORE, dos);

				// String

				writeString(this.GRADE, dos);

				// String

				writeString(this.GRADE_DATE, dos);

				// String

				writeString(this.RECORD_DATE, dos);

				// String

				writeString(this.INSPECTION_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

				// Integer

				writeInteger(this.CAMIS, dos);

				// String

				writeString(this.DBA, dos);

				// String

				writeString(this.BORO, dos);

				// String

				writeString(this.BUILDING, dos);

				// String

				writeString(this.STREET, dos);

				// String

				writeString(this.ZIPCODE, dos);

				// Long

				if (this.PHONE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.PHONE);
				}

				// String

				writeString(this.CUISINE_DESCRIPTION, dos);

				// String

				writeString(this.INSPECTION_DATE, dos);

				// String

				writeString(this.ACTION, dos);

				// String

				writeString(this.VIOLATION_CODE, dos);

				// String

				writeString(this.VIOLATION_DESCRIPTION, dos);

				// String

				writeString(this.CRITICAL_FLAG, dos);

				// String

				writeString(this.SCORE, dos);

				// String

				writeString(this.GRADE, dos);

				// String

				writeString(this.GRADE_DATE, dos);

				// String

				writeString(this.RECORD_DATE, dos);

				// String

				writeString(this.INSPECTION_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",name=" + name);
			sb.append(",host_id=" + String.valueOf(host_id));
			sb.append(",host_name=" + host_name);
			sb.append(",neighbourhood_group=" + neighbourhood_group);
			sb.append(",neighbourhood=" + neighbourhood);
			sb.append(",latitude=" + latitude);
			sb.append(",longitude=" + longitude);
			sb.append(",room_type=" + room_type);
			sb.append(",price=" + price);
			sb.append(",minimum_nights=" + String.valueOf(minimum_nights));
			sb.append(",number_of_reviews=" + number_of_reviews);
			sb.append(",last_review=" + last_review);
			sb.append(",reviews_per_month=" + reviews_per_month);
			sb.append(",calculated_host_listings_count=" + String.valueOf(calculated_host_listings_count));
			sb.append(",availability_365=" + availability_365);
			sb.append(",CAMIS=" + String.valueOf(CAMIS));
			sb.append(",DBA=" + DBA);
			sb.append(",BORO=" + BORO);
			sb.append(",BUILDING=" + BUILDING);
			sb.append(",STREET=" + STREET);
			sb.append(",ZIPCODE=" + ZIPCODE);
			sb.append(",PHONE=" + String.valueOf(PHONE));
			sb.append(",CUISINE_DESCRIPTION=" + CUISINE_DESCRIPTION);
			sb.append(",INSPECTION_DATE=" + INSPECTION_DATE);
			sb.append(",ACTION=" + ACTION);
			sb.append(",VIOLATION_CODE=" + VIOLATION_CODE);
			sb.append(",VIOLATION_DESCRIPTION=" + VIOLATION_DESCRIPTION);
			sb.append(",CRITICAL_FLAG=" + CRITICAL_FLAG);
			sb.append(",SCORE=" + SCORE);
			sb.append(",GRADE=" + GRADE);
			sb.append(",GRADE_DATE=" + GRADE_DATE);
			sb.append(",RECORD_DATE=" + RECORD_DATE);
			sb.append(",INSPECTION_TYPE=" + INSPECTION_TYPE);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String name;

		public String getName() {
			return this.name;
		}

		public Integer host_id;

		public Integer getHost_id() {
			return this.host_id;
		}

		public String host_name;

		public String getHost_name() {
			return this.host_name;
		}

		public String neighbourhood_group;

		public String getNeighbourhood_group() {
			return this.neighbourhood_group;
		}

		public String neighbourhood;

		public String getNeighbourhood() {
			return this.neighbourhood;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String room_type;

		public String getRoom_type() {
			return this.room_type;
		}

		public String price;

		public String getPrice() {
			return this.price;
		}

		public Double minimum_nights;

		public Double getMinimum_nights() {
			return this.minimum_nights;
		}

		public String number_of_reviews;

		public String getNumber_of_reviews() {
			return this.number_of_reviews;
		}

		public String last_review;

		public String getLast_review() {
			return this.last_review;
		}

		public String reviews_per_month;

		public String getReviews_per_month() {
			return this.reviews_per_month;
		}

		public Float calculated_host_listings_count;

		public Float getCalculated_host_listings_count() {
			return this.calculated_host_listings_count;
		}

		public String availability_365;

		public String getAvailability_365() {
			return this.availability_365;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",name=" + name);
			sb.append(",host_id=" + String.valueOf(host_id));
			sb.append(",host_name=" + host_name);
			sb.append(",neighbourhood_group=" + neighbourhood_group);
			sb.append(",neighbourhood=" + neighbourhood);
			sb.append(",latitude=" + latitude);
			sb.append(",longitude=" + longitude);
			sb.append(",room_type=" + room_type);
			sb.append(",price=" + price);
			sb.append(",minimum_nights=" + String.valueOf(minimum_nights));
			sb.append(",number_of_reviews=" + number_of_reviews);
			sb.append(",last_review=" + last_review);
			sb.append(",reviews_per_month=" + reviews_per_month);
			sb.append(",calculated_host_listings_count=" + String.valueOf(calculated_host_listings_count));
			sb.append(",availability_365=" + availability_365);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String name;

		public String getName() {
			return this.name;
		}

		public Integer host_id;

		public Integer getHost_id() {
			return this.host_id;
		}

		public String host_name;

		public String getHost_name() {
			return this.host_name;
		}

		public String neighbourhood_group;

		public String getNeighbourhood_group() {
			return this.neighbourhood_group;
		}

		public String neighbourhood;

		public String getNeighbourhood() {
			return this.neighbourhood;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String room_type;

		public String getRoom_type() {
			return this.room_type;
		}

		public String price;

		public String getPrice() {
			return this.price;
		}

		public Double minimum_nights;

		public Double getMinimum_nights() {
			return this.minimum_nights;
		}

		public String number_of_reviews;

		public String getNumber_of_reviews() {
			return this.number_of_reviews;
		}

		public String last_review;

		public String getLast_review() {
			return this.last_review;
		}

		public String reviews_per_month;

		public String getReviews_per_month() {
			return this.reviews_per_month;
		}

		public Float calculated_host_listings_count;

		public Float getCalculated_host_listings_count() {
			return this.calculated_host_listings_count;
		}

		public String availability_365;

		public String getAvailability_365() {
			return this.availability_365;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",name=" + name);
			sb.append(",host_id=" + String.valueOf(host_id));
			sb.append(",host_name=" + host_name);
			sb.append(",neighbourhood_group=" + neighbourhood_group);
			sb.append(",neighbourhood=" + neighbourhood);
			sb.append(",latitude=" + latitude);
			sb.append(",longitude=" + longitude);
			sb.append(",room_type=" + room_type);
			sb.append(",price=" + price);
			sb.append(",minimum_nights=" + String.valueOf(minimum_nights));
			sb.append(",number_of_reviews=" + number_of_reviews);
			sb.append(",last_review=" + last_review);
			sb.append(",reviews_per_month=" + reviews_per_month);
			sb.append(",calculated_host_listings_count=" + String.valueOf(calculated_host_listings_count));
			sb.append(",availability_365=" + availability_365);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputDelimited_1Struct
			implements routines.system.IPersistableRow<after_tFileInputDelimited_1Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String name;

		public String getName() {
			return this.name;
		}

		public Integer host_id;

		public Integer getHost_id() {
			return this.host_id;
		}

		public String host_name;

		public String getHost_name() {
			return this.host_name;
		}

		public String neighbourhood_group;

		public String getNeighbourhood_group() {
			return this.neighbourhood_group;
		}

		public String neighbourhood;

		public String getNeighbourhood() {
			return this.neighbourhood;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String room_type;

		public String getRoom_type() {
			return this.room_type;
		}

		public String price;

		public String getPrice() {
			return this.price;
		}

		public Double minimum_nights;

		public Double getMinimum_nights() {
			return this.minimum_nights;
		}

		public String number_of_reviews;

		public String getNumber_of_reviews() {
			return this.number_of_reviews;
		}

		public String last_review;

		public String getLast_review() {
			return this.last_review;
		}

		public String reviews_per_month;

		public String getReviews_per_month() {
			return this.reviews_per_month;
		}

		public Float calculated_host_listings_count;

		public Float getCalculated_host_listings_count() {
			return this.calculated_host_listings_count;
		}

		public String availability_365;

		public String getAvailability_365() {
			return this.availability_365;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.name = readString(dis);

					this.host_id = readInteger(dis);

					this.host_name = readString(dis);

					this.neighbourhood_group = readString(dis);

					this.neighbourhood = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.room_type = readString(dis);

					this.price = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.minimum_nights = null;
					} else {
						this.minimum_nights = dis.readDouble();
					}

					this.number_of_reviews = readString(dis);

					this.last_review = readString(dis);

					this.reviews_per_month = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.calculated_host_listings_count = null;
					} else {
						this.calculated_host_listings_count = dis.readFloat();
					}

					this.availability_365 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.name, dos);

				// Integer

				writeInteger(this.host_id, dos);

				// String

				writeString(this.host_name, dos);

				// String

				writeString(this.neighbourhood_group, dos);

				// String

				writeString(this.neighbourhood, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.room_type, dos);

				// String

				writeString(this.price, dos);

				// Double

				if (this.minimum_nights == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.minimum_nights);
				}

				// String

				writeString(this.number_of_reviews, dos);

				// String

				writeString(this.last_review, dos);

				// String

				writeString(this.reviews_per_month, dos);

				// Float

				if (this.calculated_host_listings_count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.calculated_host_listings_count);
				}

				// String

				writeString(this.availability_365, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",name=" + name);
			sb.append(",host_id=" + String.valueOf(host_id));
			sb.append(",host_name=" + host_name);
			sb.append(",neighbourhood_group=" + neighbourhood_group);
			sb.append(",neighbourhood=" + neighbourhood);
			sb.append(",latitude=" + latitude);
			sb.append(",longitude=" + longitude);
			sb.append(",room_type=" + room_type);
			sb.append(",price=" + price);
			sb.append(",minimum_nights=" + String.valueOf(minimum_nights));
			sb.append(",number_of_reviews=" + number_of_reviews);
			sb.append(",last_review=" + last_review);
			sb.append(",reviews_per_month=" + reviews_per_month);
			sb.append(",calculated_host_listings_count=" + String.valueOf(calculated_host_listings_count));
			sb.append(",availability_365=" + availability_365);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputDelimited_1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tFileInputDelimited_2Process(globalMap);

				row1Struct row1 = new row1Struct();
				row1Struct row2 = row1;
				out1Struct out1 = new out1Struct();

				/**
				 * [tLogRow_9 begin ] start
				 */

				ok_Hash.put("tLogRow_9", false);
				start_Hash.put("tLogRow_9", System.currentTimeMillis());

				currentComponent = "tLogRow_9";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "out1");
				}

				int tos_count_tLogRow_9 = 0;

				///////////////////////

				class Util_tLogRow_9 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[34];

					public void addRow(String[] row) {

						for (int i = 0; i < 34; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 33 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 33 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|%11$-");
							sbformat.append(colLengths[10]);
							sbformat.append("s");

							sbformat.append("|%12$-");
							sbformat.append(colLengths[11]);
							sbformat.append("s");

							sbformat.append("|%13$-");
							sbformat.append(colLengths[12]);
							sbformat.append("s");

							sbformat.append("|%14$-");
							sbformat.append(colLengths[13]);
							sbformat.append("s");

							sbformat.append("|%15$-");
							sbformat.append(colLengths[14]);
							sbformat.append("s");

							sbformat.append("|%16$-");
							sbformat.append(colLengths[15]);
							sbformat.append("s");

							sbformat.append("|%17$-");
							sbformat.append(colLengths[16]);
							sbformat.append("s");

							sbformat.append("|%18$-");
							sbformat.append(colLengths[17]);
							sbformat.append("s");

							sbformat.append("|%19$-");
							sbformat.append(colLengths[18]);
							sbformat.append("s");

							sbformat.append("|%20$-");
							sbformat.append(colLengths[19]);
							sbformat.append("s");

							sbformat.append("|%21$-");
							sbformat.append(colLengths[20]);
							sbformat.append("s");

							sbformat.append("|%22$-");
							sbformat.append(colLengths[21]);
							sbformat.append("s");

							sbformat.append("|%23$-");
							sbformat.append(colLengths[22]);
							sbformat.append("s");

							sbformat.append("|%24$-");
							sbformat.append(colLengths[23]);
							sbformat.append("s");

							sbformat.append("|%25$-");
							sbformat.append(colLengths[24]);
							sbformat.append("s");

							sbformat.append("|%26$-");
							sbformat.append(colLengths[25]);
							sbformat.append("s");

							sbformat.append("|%27$-");
							sbformat.append(colLengths[26]);
							sbformat.append("s");

							sbformat.append("|%28$-");
							sbformat.append(colLengths[27]);
							sbformat.append("s");

							sbformat.append("|%29$-");
							sbformat.append(colLengths[28]);
							sbformat.append("s");

							sbformat.append("|%30$-");
							sbformat.append(colLengths[29]);
							sbformat.append("s");

							sbformat.append("|%31$-");
							sbformat.append(colLengths[30]);
							sbformat.append("s");

							sbformat.append("|%32$-");
							sbformat.append(colLengths[31]);
							sbformat.append("s");

							sbformat.append("|%33$-");
							sbformat.append(colLengths[32]);
							sbformat.append("s");

							sbformat.append("|%34$-");
							sbformat.append(colLengths[33]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[27] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[28] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[29] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[30] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[31] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[32] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[33] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_9 util_tLogRow_9 = new Util_tLogRow_9();
				util_tLogRow_9.setTableName("tLogRow_9");
				util_tLogRow_9.addRow(new String[] { "id", "name", "host_id", "host_name", "neighbourhood_group",
						"neighbourhood", "latitude", "longitude", "room_type", "price", "minimum_nights",
						"number_of_reviews", "last_review", "reviews_per_month", "calculated_host_listings_count",
						"availability_365", "CAMIS", "DBA", "BORO", "BUILDING", "STREET", "ZIPCODE", "PHONE",
						"CUISINE_DESCRIPTION", "INSPECTION_DATE", "ACTION", "VIOLATION_CODE", "VIOLATION_DESCRIPTION",
						"CRITICAL_FLAG", "SCORE", "GRADE", "GRADE_DATE", "RECORD_DATE", "INSPECTION_TYPE", });
				StringBuilder strBuffer_tLogRow_9 = null;
				int nb_line_tLogRow_9 = 0;
///////////////////////    			

				/**
				 * [tLogRow_9 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) globalMap
						.get("tHash_Lookup_row4"));

				row4Struct row4HashKey = new row4Struct();
				row4Struct row4Default = new row4Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				out1Struct out1_tmp = new out1Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tLogRow_1 = 0;

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				int footer_tFileInputDelimited_1 = 0;
				int totalLinetFileInputDelimited_1 = 0;
				int limittFileInputDelimited_1 = 200;
				int lastLinetFileInputDelimited_1 = -1;

				char fieldSeparator_tFileInputDelimited_1[] = null;

				// support passing value (property: Field Separator) by 'context.fs' or
				// 'globalMap.get("fs")'.
				if (((String) ",").length() > 0) {
					fieldSeparator_tFileInputDelimited_1 = ((String) ",").toCharArray();
				} else {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_1[] = null;

				// support passing value (property: Row Separator) by 'context.rs' or
				// 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_1 = ((String) "\n").toCharArray();
				} else {
					throw new IllegalArgumentException("Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_1 = /** Start field tFileInputDelimited_1:FILENAME */
						"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/AirBNB1.csv"/**
																											 * End field
																											 * tFileInputDelimited_1:FILENAME
																											 */
				;
				com.talend.csv.CSVReader csvReadertFileInputDelimited_1 = null;

				try {

					String[] rowtFileInputDelimited_1 = null;
					int currentLinetFileInputDelimited_1 = 0;
					int outputLinetFileInputDelimited_1 = 0;
					try {// TD110 begin
						if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

							int footer_value_tFileInputDelimited_1 = 0;
							if (footer_value_tFileInputDelimited_1 > 0) {
								throw new java.lang.Exception(
										"When the input source is a stream,footer shouldn't be bigger than 0.");
							}

							csvReadertFileInputDelimited_1 = new com.talend.csv.CSVReader(
									(java.io.InputStream) filename_tFileInputDelimited_1,
									fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
						} else {
							csvReadertFileInputDelimited_1 = new com.talend.csv.CSVReader(
									String.valueOf(filename_tFileInputDelimited_1),
									fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
						}

						csvReadertFileInputDelimited_1.setTrimWhitespace(false);
						if ((rowSeparator_tFileInputDelimited_1[0] != '\n')
								&& (rowSeparator_tFileInputDelimited_1[0] != '\r'))
							csvReadertFileInputDelimited_1.setLineEnd("" + rowSeparator_tFileInputDelimited_1[0]);

						csvReadertFileInputDelimited_1.setQuoteChar('"');

						csvReadertFileInputDelimited_1.setEscapeChar(csvReadertFileInputDelimited_1.getQuoteChar());

						if (footer_tFileInputDelimited_1 > 0) {
							for (totalLinetFileInputDelimited_1 = 0; totalLinetFileInputDelimited_1 < 1; totalLinetFileInputDelimited_1++) {
								csvReadertFileInputDelimited_1.readNext();
							}
							csvReadertFileInputDelimited_1.setSkipEmptyRecords(false);
							while (csvReadertFileInputDelimited_1.readNext()) {

								totalLinetFileInputDelimited_1++;

							}
							int lastLineTemptFileInputDelimited_1 = totalLinetFileInputDelimited_1
									- footer_tFileInputDelimited_1 < 0 ? 0
											: totalLinetFileInputDelimited_1 - footer_tFileInputDelimited_1;
							if (lastLinetFileInputDelimited_1 > 0) {
								lastLinetFileInputDelimited_1 = lastLinetFileInputDelimited_1 < lastLineTemptFileInputDelimited_1
										? lastLinetFileInputDelimited_1
										: lastLineTemptFileInputDelimited_1;
							} else {
								lastLinetFileInputDelimited_1 = lastLineTemptFileInputDelimited_1;
							}

							csvReadertFileInputDelimited_1.close();
							if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {
								csvReadertFileInputDelimited_1 = new com.talend.csv.CSVReader(
										(java.io.InputStream) filename_tFileInputDelimited_1,
										fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
							} else {
								csvReadertFileInputDelimited_1 = new com.talend.csv.CSVReader(
										String.valueOf(filename_tFileInputDelimited_1),
										fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
							}
							csvReadertFileInputDelimited_1.setTrimWhitespace(false);
							if ((rowSeparator_tFileInputDelimited_1[0] != '\n')
									&& (rowSeparator_tFileInputDelimited_1[0] != '\r'))
								csvReadertFileInputDelimited_1.setLineEnd("" + rowSeparator_tFileInputDelimited_1[0]);

							csvReadertFileInputDelimited_1.setQuoteChar('"');

							csvReadertFileInputDelimited_1.setEscapeChar(csvReadertFileInputDelimited_1.getQuoteChar());

						}

						if (limittFileInputDelimited_1 != 0) {
							for (currentLinetFileInputDelimited_1 = 0; currentLinetFileInputDelimited_1 < 1; currentLinetFileInputDelimited_1++) {
								csvReadertFileInputDelimited_1.readNext();
							}
						}
						csvReadertFileInputDelimited_1.setSkipEmptyRecords(false);

					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					} // TD110 end

					while (limittFileInputDelimited_1 != 0 && csvReadertFileInputDelimited_1 != null
							&& csvReadertFileInputDelimited_1.readNext()) {
						rowstate_tFileInputDelimited_1.reset();

						rowtFileInputDelimited_1 = csvReadertFileInputDelimited_1.getValues();

						currentLinetFileInputDelimited_1++;

						if (lastLinetFileInputDelimited_1 > -1
								&& currentLinetFileInputDelimited_1 > lastLinetFileInputDelimited_1) {
							break;
						}
						outputLinetFileInputDelimited_1++;
						if (limittFileInputDelimited_1 > 0
								&& outputLinetFileInputDelimited_1 > limittFileInputDelimited_1) {
							break;
						}

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							char fieldSeparator_tFileInputDelimited_1_ListType[] = null;
							// support passing value (property: Field Separator) by 'context.fs' or
							// 'globalMap.get("fs")'.
							if (((String) ",").length() > 0) {
								fieldSeparator_tFileInputDelimited_1_ListType = ((String) ",").toCharArray();
							} else {
								throw new IllegalArgumentException("Field Separator must be assigned a char.");
							}
							if (rowtFileInputDelimited_1.length == 1 && ("\015").equals(rowtFileInputDelimited_1[0])) {// empty
																														// line
																														// when
																														// row
																														// separator
																														// is
																														// '\n'

								row1.id = null;

								row1.name = null;

								row1.host_id = null;

								row1.host_name = null;

								row1.neighbourhood_group = null;

								row1.neighbourhood = null;

								row1.latitude = null;

								row1.longitude = null;

								row1.room_type = null;

								row1.price = null;

								row1.minimum_nights = null;

								row1.number_of_reviews = null;

								row1.last_review = null;

								row1.reviews_per_month = null;

								row1.calculated_host_listings_count = null;

								row1.availability_365 = null;

							} else {

								int columnIndexWithD_tFileInputDelimited_1 = 0; // Column Index

								columnIndexWithD_tFileInputDelimited_1 = 0;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									if (rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {

											row1.id = ParserUtils.parseTo_Integer(
													rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);

										} catch (java.lang.Exception ex_tFileInputDelimited_1) {
											globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
													ex_tFileInputDelimited_1.getMessage());
											rowstate_tFileInputDelimited_1.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"id", "row1",
															rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1],
															ex_tFileInputDelimited_1),
													ex_tFileInputDelimited_1));
										}
									} else {

										row1.id = null;

									}

								} else {

									row1.id = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 1;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.name = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.name = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 2;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									if (rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {

											row1.host_id = ParserUtils.parseTo_Integer(
													rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);

										} catch (java.lang.Exception ex_tFileInputDelimited_1) {
											globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
													ex_tFileInputDelimited_1.getMessage());
											rowstate_tFileInputDelimited_1.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"host_id", "row1",
															rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1],
															ex_tFileInputDelimited_1),
													ex_tFileInputDelimited_1));
										}
									} else {

										row1.host_id = null;

									}

								} else {

									row1.host_id = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 3;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.host_name = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.host_name = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 4;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.neighbourhood_group = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.neighbourhood_group = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 5;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.neighbourhood = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.neighbourhood = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 6;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.latitude = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.latitude = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 7;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.longitude = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.longitude = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 8;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.room_type = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.room_type = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 9;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.price = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.price = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 10;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									if (rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {

											row1.minimum_nights = ParserUtils.parseTo_Double(
													rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);

										} catch (java.lang.Exception ex_tFileInputDelimited_1) {
											globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
													ex_tFileInputDelimited_1.getMessage());
											rowstate_tFileInputDelimited_1.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"minimum_nights", "row1",
															rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1],
															ex_tFileInputDelimited_1),
													ex_tFileInputDelimited_1));
										}
									} else {

										row1.minimum_nights = null;

									}

								} else {

									row1.minimum_nights = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 11;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.number_of_reviews = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.number_of_reviews = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 12;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.last_review = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.last_review = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 13;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.reviews_per_month = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.reviews_per_month = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 14;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									if (rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {

											row1.calculated_host_listings_count = ParserUtils.parseTo_Float(
													rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);

										} catch (java.lang.Exception ex_tFileInputDelimited_1) {
											globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
													ex_tFileInputDelimited_1.getMessage());
											rowstate_tFileInputDelimited_1.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"calculated_host_listings_count", "row1",
															rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1],
															ex_tFileInputDelimited_1),
													ex_tFileInputDelimited_1));
										}
									} else {

										row1.calculated_host_listings_count = null;

									}

								} else {

									row1.calculated_host_listings_count = null;

								}

								columnIndexWithD_tFileInputDelimited_1 = 15;

								if (columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length) {

									row1.availability_365 = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];

								} else {

									row1.availability_365 = null;

								}

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row1 = null;

							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tLogRow_1 main ] start
							 */

							currentComponent = "tLogRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							row2 = row1;

							tos_count_tLogRow_1++;

							/**
							 * [tLogRow_1 main ] stop
							 */

							/**
							 * [tLogRow_1 process_data_begin ] start
							 */

							currentComponent = "tLogRow_1";

							/**
							 * [tLogRow_1 process_data_begin ] stop
							 */

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row2"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							///////////////////////////////////////////////
							// Starting Lookup Table "row4"
							///////////////////////////////////////////////

							boolean forceLooprow4 = false;

							row4Struct row4ObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_1 = false;

								row4HashKey.BORO = StringHandling.UPCASE(row2.neighbourhood_group);

								row4HashKey.hashCodeDirty = true;

								tHash_Lookup_row4.lookup(row4HashKey);

								if (!tHash_Lookup_row4.hasNext()) { // G_TM_M_090

									rejectedInnerJoin_tMap_1 = true;

								} // G_TM_M_090

							} // G_TM_M_020

							if (tHash_Lookup_row4 != null && tHash_Lookup_row4.getCount(row4HashKey) > 1) { // G 071

								// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row4'
								// and it contains more one result from keys : row4.BORO = '" + row4HashKey.BORO
								// + "'");
							} // G 071

							row4Struct row4 = null;

							row4Struct fromLookup_row4 = null;
							row4 = row4Default;

							if (tHash_Lookup_row4 != null && tHash_Lookup_row4.hasNext()) { // G 099

								fromLookup_row4 = tHash_Lookup_row4.next();

							} // G 099

							if (fromLookup_row4 != null) {
								row4 = fromLookup_row4;
							}

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								out1 = null;

								if (!rejectedInnerJoin_tMap_1) {

// # Output table : 'out1'
									out1_tmp.id = row2.id;
									out1_tmp.name = row2.name;
									out1_tmp.host_id = row2.host_id;
									out1_tmp.host_name = row2.host_name;
									out1_tmp.neighbourhood_group = row2.neighbourhood_group;
									out1_tmp.neighbourhood = row2.neighbourhood;
									out1_tmp.latitude = row2.latitude;
									out1_tmp.longitude = row2.longitude;
									out1_tmp.room_type = row2.room_type;
									out1_tmp.price = row2.price;
									out1_tmp.minimum_nights = row2.minimum_nights;
									out1_tmp.number_of_reviews = row2.number_of_reviews;
									out1_tmp.last_review = row2.last_review;
									out1_tmp.reviews_per_month = row2.reviews_per_month;
									out1_tmp.calculated_host_listings_count = row2.calculated_host_listings_count;
									out1_tmp.availability_365 = row2.availability_365;
									out1_tmp.CAMIS = row4.CAMIS;
									out1_tmp.DBA = row4.DBA;
									out1_tmp.BORO = row4.BORO;
									out1_tmp.BUILDING = row4.BUILDING;
									out1_tmp.STREET = row4.STREET;
									out1_tmp.ZIPCODE = row4.ZIPCODE;
									out1_tmp.PHONE = row4.PHONE;
									out1_tmp.CUISINE_DESCRIPTION = row4.CUISINE_DESCRIPTION;
									out1_tmp.INSPECTION_DATE = row4.INSPECTION_DATE;
									out1_tmp.ACTION = row4.ACTION;
									out1_tmp.VIOLATION_CODE = row4.VIOLATION_CODE;
									out1_tmp.VIOLATION_DESCRIPTION = row4.VIOLATION_DESCRIPTION;
									out1_tmp.CRITICAL_FLAG = row4.CRITICAL_FLAG;
									out1_tmp.SCORE = row4.SCORE;
									out1_tmp.GRADE = row4.GRADE;
									out1_tmp.GRADE_DATE = row4.GRADE_DATE;
									out1_tmp.RECORD_DATE = row4.RECORD_DATE;
									out1_tmp.INSPECTION_TYPE = row4.INSPECTION_TYPE;
									out1 = out1_tmp;
								} // closing inner join bracket (2)
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "out1"
							if (out1 != null) {

								/**
								 * [tLogRow_9 main ] start
								 */

								currentComponent = "tLogRow_9";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "out1"

									);
								}

///////////////////////		

								String[] row_tLogRow_9 = new String[34];

								if (out1.id != null) { //
									row_tLogRow_9[0] = String.valueOf(out1.id);

								} //

								if (out1.name != null) { //
									row_tLogRow_9[1] = String.valueOf(out1.name);

								} //

								if (out1.host_id != null) { //
									row_tLogRow_9[2] = String.valueOf(out1.host_id);

								} //

								if (out1.host_name != null) { //
									row_tLogRow_9[3] = String.valueOf(out1.host_name);

								} //

								if (out1.neighbourhood_group != null) { //
									row_tLogRow_9[4] = String.valueOf(out1.neighbourhood_group);

								} //

								if (out1.neighbourhood != null) { //
									row_tLogRow_9[5] = String.valueOf(out1.neighbourhood);

								} //

								if (out1.latitude != null) { //
									row_tLogRow_9[6] = String.valueOf(out1.latitude);

								} //

								if (out1.longitude != null) { //
									row_tLogRow_9[7] = String.valueOf(out1.longitude);

								} //

								if (out1.room_type != null) { //
									row_tLogRow_9[8] = String.valueOf(out1.room_type);

								} //

								if (out1.price != null) { //
									row_tLogRow_9[9] = String.valueOf(out1.price);

								} //

								if (out1.minimum_nights != null) { //
									row_tLogRow_9[10] = FormatterUtils.formatUnwithE(out1.minimum_nights);

								} //

								if (out1.number_of_reviews != null) { //
									row_tLogRow_9[11] = String.valueOf(out1.number_of_reviews);

								} //

								if (out1.last_review != null) { //
									row_tLogRow_9[12] = String.valueOf(out1.last_review);

								} //

								if (out1.reviews_per_month != null) { //
									row_tLogRow_9[13] = String.valueOf(out1.reviews_per_month);

								} //

								if (out1.calculated_host_listings_count != null) { //
									row_tLogRow_9[14] = FormatterUtils
											.formatUnwithE(out1.calculated_host_listings_count);

								} //

								if (out1.availability_365 != null) { //
									row_tLogRow_9[15] = String.valueOf(out1.availability_365);

								} //

								if (out1.CAMIS != null) { //
									row_tLogRow_9[16] = String.valueOf(out1.CAMIS);

								} //

								if (out1.DBA != null) { //
									row_tLogRow_9[17] = String.valueOf(out1.DBA);

								} //

								if (out1.BORO != null) { //
									row_tLogRow_9[18] = String.valueOf(out1.BORO);

								} //

								if (out1.BUILDING != null) { //
									row_tLogRow_9[19] = String.valueOf(out1.BUILDING);

								} //

								if (out1.STREET != null) { //
									row_tLogRow_9[20] = String.valueOf(out1.STREET);

								} //

								if (out1.ZIPCODE != null) { //
									row_tLogRow_9[21] = String.valueOf(out1.ZIPCODE);

								} //

								if (out1.PHONE != null) { //
									row_tLogRow_9[22] = String.valueOf(out1.PHONE);

								} //

								if (out1.CUISINE_DESCRIPTION != null) { //
									row_tLogRow_9[23] = String.valueOf(out1.CUISINE_DESCRIPTION);

								} //

								if (out1.INSPECTION_DATE != null) { //
									row_tLogRow_9[24] = String.valueOf(out1.INSPECTION_DATE);

								} //

								if (out1.ACTION != null) { //
									row_tLogRow_9[25] = String.valueOf(out1.ACTION);

								} //

								if (out1.VIOLATION_CODE != null) { //
									row_tLogRow_9[26] = String.valueOf(out1.VIOLATION_CODE);

								} //

								if (out1.VIOLATION_DESCRIPTION != null) { //
									row_tLogRow_9[27] = String.valueOf(out1.VIOLATION_DESCRIPTION);

								} //

								if (out1.CRITICAL_FLAG != null) { //
									row_tLogRow_9[28] = String.valueOf(out1.CRITICAL_FLAG);

								} //

								if (out1.SCORE != null) { //
									row_tLogRow_9[29] = String.valueOf(out1.SCORE);

								} //

								if (out1.GRADE != null) { //
									row_tLogRow_9[30] = String.valueOf(out1.GRADE);

								} //

								if (out1.GRADE_DATE != null) { //
									row_tLogRow_9[31] = String.valueOf(out1.GRADE_DATE);

								} //

								if (out1.RECORD_DATE != null) { //
									row_tLogRow_9[32] = String.valueOf(out1.RECORD_DATE);

								} //

								if (out1.INSPECTION_TYPE != null) { //
									row_tLogRow_9[33] = String.valueOf(out1.INSPECTION_TYPE);

								} //

								util_tLogRow_9.addRow(row_tLogRow_9);
								nb_line_tLogRow_9++;
//////

//////                    

///////////////////////    			

								tos_count_tLogRow_9++;

								/**
								 * [tLogRow_9 main ] stop
								 */

								/**
								 * [tLogRow_9 process_data_begin ] start
								 */

								currentComponent = "tLogRow_9";

								/**
								 * [tLogRow_9 process_data_begin ] stop
								 */

								/**
								 * [tLogRow_9 process_data_end ] start
								 */

								currentComponent = "tLogRow_9";

								/**
								 * [tLogRow_9 process_data_end ] stop
								 */

							} // End of branch "out1"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

							/**
							 * [tLogRow_1 process_data_end ] start
							 */

							currentComponent = "tLogRow_1";

							/**
							 * [tLogRow_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						nb_line_tFileInputDelimited_1++;
					}

				} finally {
					if (!(filename_tFileInputDelimited_1 instanceof java.io.InputStream)) {
						if (csvReadertFileInputDelimited_1 != null) {
							csvReadertFileInputDelimited_1.close();
						}
					}
					if (csvReadertFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", nb_line_tFileInputDelimited_1);
					}

				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row4 != null) {
					tHash_Lookup_row4.endGet();
				}
				globalMap.remove("tHash_Lookup_row4");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tLogRow_9 end ] start
				 */

				currentComponent = "tLogRow_9";

//////

				java.io.PrintStream consoleOut_tLogRow_9 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_9 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_9 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_9);
				}

				consoleOut_tLogRow_9.println(util_tLogRow_9.format().toString());
				consoleOut_tLogRow_9.flush();
//////
				globalMap.put("tLogRow_9_NB_LINE", nb_line_tLogRow_9);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "out1");
				}

				ok_Hash.put("tLogRow_9", true);
				end_Hash.put("tLogRow_9", System.currentTimeMillis());

				/**
				 * [tLogRow_9 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row4");

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tLogRow_9 finally ] start
				 */

				currentComponent = "tLogRow_9";

				/**
				 * [tLogRow_9 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer CAMIS;

		public Integer getCAMIS() {
			return this.CAMIS;
		}

		public String DBA;

		public String getDBA() {
			return this.DBA;
		}

		public String BORO;

		public String getBORO() {
			return this.BORO;
		}

		public String BUILDING;

		public String getBUILDING() {
			return this.BUILDING;
		}

		public String STREET;

		public String getSTREET() {
			return this.STREET;
		}

		public String ZIPCODE;

		public String getZIPCODE() {
			return this.ZIPCODE;
		}

		public Long PHONE;

		public Long getPHONE() {
			return this.PHONE;
		}

		public String CUISINE_DESCRIPTION;

		public String getCUISINE_DESCRIPTION() {
			return this.CUISINE_DESCRIPTION;
		}

		public String INSPECTION_DATE;

		public String getINSPECTION_DATE() {
			return this.INSPECTION_DATE;
		}

		public String ACTION;

		public String getACTION() {
			return this.ACTION;
		}

		public String VIOLATION_CODE;

		public String getVIOLATION_CODE() {
			return this.VIOLATION_CODE;
		}

		public String VIOLATION_DESCRIPTION;

		public String getVIOLATION_DESCRIPTION() {
			return this.VIOLATION_DESCRIPTION;
		}

		public String CRITICAL_FLAG;

		public String getCRITICAL_FLAG() {
			return this.CRITICAL_FLAG;
		}

		public String SCORE;

		public String getSCORE() {
			return this.SCORE;
		}

		public String GRADE;

		public String getGRADE() {
			return this.GRADE;
		}

		public String GRADE_DATE;

		public String getGRADE_DATE() {
			return this.GRADE_DATE;
		}

		public String RECORD_DATE;

		public String getRECORD_DATE() {
			return this.RECORD_DATE;
		}

		public String INSPECTION_TYPE;

		public String getINSPECTION_TYPE() {
			return this.INSPECTION_TYPE;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.BORO == null) ? 0 : this.BORO.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row4Struct other = (row4Struct) obj;

			if (this.BORO == null) {
				if (other.BORO != null)
					return false;

			} else if (!this.BORO.equals(other.BORO))

				return false;

			return true;
		}

		public void copyDataTo(row4Struct other) {

			other.CAMIS = this.CAMIS;
			other.DBA = this.DBA;
			other.BORO = this.BORO;
			other.BUILDING = this.BUILDING;
			other.STREET = this.STREET;
			other.ZIPCODE = this.ZIPCODE;
			other.PHONE = this.PHONE;
			other.CUISINE_DESCRIPTION = this.CUISINE_DESCRIPTION;
			other.INSPECTION_DATE = this.INSPECTION_DATE;
			other.ACTION = this.ACTION;
			other.VIOLATION_CODE = this.VIOLATION_CODE;
			other.VIOLATION_DESCRIPTION = this.VIOLATION_DESCRIPTION;
			other.CRITICAL_FLAG = this.CRITICAL_FLAG;
			other.SCORE = this.SCORE;
			other.GRADE = this.GRADE;
			other.GRADE_DATE = this.GRADE_DATE;
			other.RECORD_DATE = this.RECORD_DATE;
			other.INSPECTION_TYPE = this.INSPECTION_TYPE;

		}

		public void copyKeysDataTo(row4Struct other) {

			other.BORO = this.BORO;

		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.BORO = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.BORO = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BORO, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BORO, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.CAMIS = readInteger(dis, ois);

				this.DBA = readString(dis, ois);

				this.BUILDING = readString(dis, ois);

				this.STREET = readString(dis, ois);

				this.ZIPCODE = readString(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.PHONE = null;
				} else {
					this.PHONE = dis.readLong();
				}

				this.CUISINE_DESCRIPTION = readString(dis, ois);

				this.INSPECTION_DATE = readString(dis, ois);

				this.ACTION = readString(dis, ois);

				this.VIOLATION_CODE = readString(dis, ois);

				this.VIOLATION_DESCRIPTION = readString(dis, ois);

				this.CRITICAL_FLAG = readString(dis, ois);

				this.SCORE = readString(dis, ois);

				this.GRADE = readString(dis, ois);

				this.GRADE_DATE = readString(dis, ois);

				this.RECORD_DATE = readString(dis, ois);

				this.INSPECTION_TYPE = readString(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.CAMIS = readInteger(dis, objectIn);

				this.DBA = readString(dis, objectIn);

				this.BUILDING = readString(dis, objectIn);

				this.STREET = readString(dis, objectIn);

				this.ZIPCODE = readString(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.PHONE = null;
				} else {
					this.PHONE = objectIn.readLong();
				}

				this.CUISINE_DESCRIPTION = readString(dis, objectIn);

				this.INSPECTION_DATE = readString(dis, objectIn);

				this.ACTION = readString(dis, objectIn);

				this.VIOLATION_CODE = readString(dis, objectIn);

				this.VIOLATION_DESCRIPTION = readString(dis, objectIn);

				this.CRITICAL_FLAG = readString(dis, objectIn);

				this.SCORE = readString(dis, objectIn);

				this.GRADE = readString(dis, objectIn);

				this.GRADE_DATE = readString(dis, objectIn);

				this.RECORD_DATE = readString(dis, objectIn);

				this.INSPECTION_TYPE = readString(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeInteger(this.CAMIS, dos, oos);

				writeString(this.DBA, dos, oos);

				writeString(this.BUILDING, dos, oos);

				writeString(this.STREET, dos, oos);

				writeString(this.ZIPCODE, dos, oos);

				if (this.PHONE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.PHONE);
				}

				writeString(this.CUISINE_DESCRIPTION, dos, oos);

				writeString(this.INSPECTION_DATE, dos, oos);

				writeString(this.ACTION, dos, oos);

				writeString(this.VIOLATION_CODE, dos, oos);

				writeString(this.VIOLATION_DESCRIPTION, dos, oos);

				writeString(this.CRITICAL_FLAG, dos, oos);

				writeString(this.SCORE, dos, oos);

				writeString(this.GRADE, dos, oos);

				writeString(this.GRADE_DATE, dos, oos);

				writeString(this.RECORD_DATE, dos, oos);

				writeString(this.INSPECTION_TYPE, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeInteger(this.CAMIS, dos, objectOut);

				writeString(this.DBA, dos, objectOut);

				writeString(this.BUILDING, dos, objectOut);

				writeString(this.STREET, dos, objectOut);

				writeString(this.ZIPCODE, dos, objectOut);

				if (this.PHONE == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeLong(this.PHONE);
				}

				writeString(this.CUISINE_DESCRIPTION, dos, objectOut);

				writeString(this.INSPECTION_DATE, dos, objectOut);

				writeString(this.ACTION, dos, objectOut);

				writeString(this.VIOLATION_CODE, dos, objectOut);

				writeString(this.VIOLATION_DESCRIPTION, dos, objectOut);

				writeString(this.CRITICAL_FLAG, dos, objectOut);

				writeString(this.SCORE, dos, objectOut);

				writeString(this.GRADE, dos, objectOut);

				writeString(this.GRADE_DATE, dos, objectOut);

				writeString(this.RECORD_DATE, dos, objectOut);

				writeString(this.INSPECTION_TYPE, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CAMIS=" + String.valueOf(CAMIS));
			sb.append(",DBA=" + DBA);
			sb.append(",BORO=" + BORO);
			sb.append(",BUILDING=" + BUILDING);
			sb.append(",STREET=" + STREET);
			sb.append(",ZIPCODE=" + ZIPCODE);
			sb.append(",PHONE=" + String.valueOf(PHONE));
			sb.append(",CUISINE_DESCRIPTION=" + CUISINE_DESCRIPTION);
			sb.append(",INSPECTION_DATE=" + INSPECTION_DATE);
			sb.append(",ACTION=" + ACTION);
			sb.append(",VIOLATION_CODE=" + VIOLATION_CODE);
			sb.append(",VIOLATION_DESCRIPTION=" + VIOLATION_DESCRIPTION);
			sb.append(",CRITICAL_FLAG=" + CRITICAL_FLAG);
			sb.append(",SCORE=" + SCORE);
			sb.append(",GRADE=" + GRADE);
			sb.append(",GRADE_DATE=" + GRADE_DATE);
			sb.append(",RECORD_DATE=" + RECORD_DATE);
			sb.append(",INSPECTION_TYPE=" + INSPECTION_TYPE);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.BORO, other.BORO);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Integer CAMIS;

		public Integer getCAMIS() {
			return this.CAMIS;
		}

		public String DBA;

		public String getDBA() {
			return this.DBA;
		}

		public String BORO;

		public String getBORO() {
			return this.BORO;
		}

		public String BUILDING;

		public String getBUILDING() {
			return this.BUILDING;
		}

		public String STREET;

		public String getSTREET() {
			return this.STREET;
		}

		public String ZIPCODE;

		public String getZIPCODE() {
			return this.ZIPCODE;
		}

		public Long PHONE;

		public Long getPHONE() {
			return this.PHONE;
		}

		public String CUISINE_DESCRIPTION;

		public String getCUISINE_DESCRIPTION() {
			return this.CUISINE_DESCRIPTION;
		}

		public String INSPECTION_DATE;

		public String getINSPECTION_DATE() {
			return this.INSPECTION_DATE;
		}

		public String ACTION;

		public String getACTION() {
			return this.ACTION;
		}

		public String VIOLATION_CODE;

		public String getVIOLATION_CODE() {
			return this.VIOLATION_CODE;
		}

		public String VIOLATION_DESCRIPTION;

		public String getVIOLATION_DESCRIPTION() {
			return this.VIOLATION_DESCRIPTION;
		}

		public String CRITICAL_FLAG;

		public String getCRITICAL_FLAG() {
			return this.CRITICAL_FLAG;
		}

		public String SCORE;

		public String getSCORE() {
			return this.SCORE;
		}

		public String GRADE;

		public String getGRADE() {
			return this.GRADE;
		}

		public String GRADE_DATE;

		public String getGRADE_DATE() {
			return this.GRADE_DATE;
		}

		public String RECORD_DATE;

		public String getRECORD_DATE() {
			return this.RECORD_DATE;
		}

		public String INSPECTION_TYPE;

		public String getINSPECTION_TYPE() {
			return this.INSPECTION_TYPE;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.CAMIS = readInteger(dis);

					this.DBA = readString(dis);

					this.BORO = readString(dis);

					this.BUILDING = readString(dis);

					this.STREET = readString(dis);

					this.ZIPCODE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PHONE = null;
					} else {
						this.PHONE = dis.readLong();
					}

					this.CUISINE_DESCRIPTION = readString(dis);

					this.INSPECTION_DATE = readString(dis);

					this.ACTION = readString(dis);

					this.VIOLATION_CODE = readString(dis);

					this.VIOLATION_DESCRIPTION = readString(dis);

					this.CRITICAL_FLAG = readString(dis);

					this.SCORE = readString(dis);

					this.GRADE = readString(dis);

					this.GRADE_DATE = readString(dis);

					this.RECORD_DATE = readString(dis);

					this.INSPECTION_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.CAMIS = readInteger(dis);

					this.DBA = readString(dis);

					this.BORO = readString(dis);

					this.BUILDING = readString(dis);

					this.STREET = readString(dis);

					this.ZIPCODE = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PHONE = null;
					} else {
						this.PHONE = dis.readLong();
					}

					this.CUISINE_DESCRIPTION = readString(dis);

					this.INSPECTION_DATE = readString(dis);

					this.ACTION = readString(dis);

					this.VIOLATION_CODE = readString(dis);

					this.VIOLATION_DESCRIPTION = readString(dis);

					this.CRITICAL_FLAG = readString(dis);

					this.SCORE = readString(dis);

					this.GRADE = readString(dis);

					this.GRADE_DATE = readString(dis);

					this.RECORD_DATE = readString(dis);

					this.INSPECTION_TYPE = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.CAMIS, dos);

				// String

				writeString(this.DBA, dos);

				// String

				writeString(this.BORO, dos);

				// String

				writeString(this.BUILDING, dos);

				// String

				writeString(this.STREET, dos);

				// String

				writeString(this.ZIPCODE, dos);

				// Long

				if (this.PHONE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.PHONE);
				}

				// String

				writeString(this.CUISINE_DESCRIPTION, dos);

				// String

				writeString(this.INSPECTION_DATE, dos);

				// String

				writeString(this.ACTION, dos);

				// String

				writeString(this.VIOLATION_CODE, dos);

				// String

				writeString(this.VIOLATION_DESCRIPTION, dos);

				// String

				writeString(this.CRITICAL_FLAG, dos);

				// String

				writeString(this.SCORE, dos);

				// String

				writeString(this.GRADE, dos);

				// String

				writeString(this.GRADE_DATE, dos);

				// String

				writeString(this.RECORD_DATE, dos);

				// String

				writeString(this.INSPECTION_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.CAMIS, dos);

				// String

				writeString(this.DBA, dos);

				// String

				writeString(this.BORO, dos);

				// String

				writeString(this.BUILDING, dos);

				// String

				writeString(this.STREET, dos);

				// String

				writeString(this.ZIPCODE, dos);

				// Long

				if (this.PHONE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.PHONE);
				}

				// String

				writeString(this.CUISINE_DESCRIPTION, dos);

				// String

				writeString(this.INSPECTION_DATE, dos);

				// String

				writeString(this.ACTION, dos);

				// String

				writeString(this.VIOLATION_CODE, dos);

				// String

				writeString(this.VIOLATION_DESCRIPTION, dos);

				// String

				writeString(this.CRITICAL_FLAG, dos);

				// String

				writeString(this.SCORE, dos);

				// String

				writeString(this.GRADE, dos);

				// String

				writeString(this.GRADE_DATE, dos);

				// String

				writeString(this.RECORD_DATE, dos);

				// String

				writeString(this.INSPECTION_TYPE, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CAMIS=" + String.valueOf(CAMIS));
			sb.append(",DBA=" + DBA);
			sb.append(",BORO=" + BORO);
			sb.append(",BUILDING=" + BUILDING);
			sb.append(",STREET=" + STREET);
			sb.append(",ZIPCODE=" + ZIPCODE);
			sb.append(",PHONE=" + String.valueOf(PHONE));
			sb.append(",CUISINE_DESCRIPTION=" + CUISINE_DESCRIPTION);
			sb.append(",INSPECTION_DATE=" + INSPECTION_DATE);
			sb.append(",ACTION=" + ACTION);
			sb.append(",VIOLATION_CODE=" + VIOLATION_CODE);
			sb.append(",VIOLATION_DESCRIPTION=" + VIOLATION_DESCRIPTION);
			sb.append(",CRITICAL_FLAG=" + CRITICAL_FLAG);
			sb.append(",SCORE=" + SCORE);
			sb.append(",GRADE=" + GRADE);
			sb.append(",GRADE_DATE=" + GRADE_DATE);
			sb.append(",RECORD_DATE=" + RECORD_DATE);
			sb.append(",INSPECTION_TYPE=" + INSPECTION_TYPE);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();
				row3Struct row4 = row3;

				/**
				 * [tAdvancedHash_row4 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row4", false);
				start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tAdvancedHash_row4 = 0;

				// connection name:row4
				// source node:tLogRow_3 - inputs:(row3) outputs:(row4,row4) | target
				// node:tAdvancedHash_row4 - inputs:(row4) outputs:()
				// linked node: tMap_1 - inputs:(row2,row4) outputs:(out1)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row4Struct>getLookup(matchingModeEnum_row4);

				globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);

				/**
				 * [tAdvancedHash_row4 begin ] stop
				 */

				/**
				 * [tLogRow_3 begin ] start
				 */

				ok_Hash.put("tLogRow_3", false);
				start_Hash.put("tLogRow_3", System.currentTimeMillis());

				currentComponent = "tLogRow_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tLogRow_3 = 0;

				/**
				 * [tLogRow_3 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				int footer_tFileInputDelimited_2 = 0;
				int totalLinetFileInputDelimited_2 = 0;
				int limittFileInputDelimited_2 = 200;
				int lastLinetFileInputDelimited_2 = -1;

				char fieldSeparator_tFileInputDelimited_2[] = null;

				// support passing value (property: Field Separator) by 'context.fs' or
				// 'globalMap.get("fs")'.
				if (((String) ",").length() > 0) {
					fieldSeparator_tFileInputDelimited_2 = ((String) ",").toCharArray();
				} else {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_2[] = null;

				// support passing value (property: Row Separator) by 'context.rs' or
				// 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_2 = ((String) "\n").toCharArray();
				} else {
					throw new IllegalArgumentException("Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_2 = /** Start field tFileInputDelimited_2:FILENAME */
						"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/RestaurantInspection.csv"/**
																														 * End
																														 * field
																														 * tFileInputDelimited_2:FILENAME
																														 */
				;
				com.talend.csv.CSVReader csvReadertFileInputDelimited_2 = null;

				try {

					String[] rowtFileInputDelimited_2 = null;
					int currentLinetFileInputDelimited_2 = 0;
					int outputLinetFileInputDelimited_2 = 0;
					try {// TD110 begin
						if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

							int footer_value_tFileInputDelimited_2 = 0;
							if (footer_value_tFileInputDelimited_2 > 0) {
								throw new java.lang.Exception(
										"When the input source is a stream,footer shouldn't be bigger than 0.");
							}

							csvReadertFileInputDelimited_2 = new com.talend.csv.CSVReader(
									(java.io.InputStream) filename_tFileInputDelimited_2,
									fieldSeparator_tFileInputDelimited_2[0], "UTF-8");
						} else {
							csvReadertFileInputDelimited_2 = new com.talend.csv.CSVReader(
									String.valueOf(filename_tFileInputDelimited_2),
									fieldSeparator_tFileInputDelimited_2[0], "UTF-8");
						}

						csvReadertFileInputDelimited_2.setTrimWhitespace(false);
						if ((rowSeparator_tFileInputDelimited_2[0] != '\n')
								&& (rowSeparator_tFileInputDelimited_2[0] != '\r'))
							csvReadertFileInputDelimited_2.setLineEnd("" + rowSeparator_tFileInputDelimited_2[0]);

						csvReadertFileInputDelimited_2.setQuoteChar('"');

						csvReadertFileInputDelimited_2.setEscapeChar(csvReadertFileInputDelimited_2.getQuoteChar());

						if (footer_tFileInputDelimited_2 > 0) {
							for (totalLinetFileInputDelimited_2 = 0; totalLinetFileInputDelimited_2 < 1; totalLinetFileInputDelimited_2++) {
								csvReadertFileInputDelimited_2.readNext();
							}
							csvReadertFileInputDelimited_2.setSkipEmptyRecords(false);
							while (csvReadertFileInputDelimited_2.readNext()) {

								totalLinetFileInputDelimited_2++;

							}
							int lastLineTemptFileInputDelimited_2 = totalLinetFileInputDelimited_2
									- footer_tFileInputDelimited_2 < 0 ? 0
											: totalLinetFileInputDelimited_2 - footer_tFileInputDelimited_2;
							if (lastLinetFileInputDelimited_2 > 0) {
								lastLinetFileInputDelimited_2 = lastLinetFileInputDelimited_2 < lastLineTemptFileInputDelimited_2
										? lastLinetFileInputDelimited_2
										: lastLineTemptFileInputDelimited_2;
							} else {
								lastLinetFileInputDelimited_2 = lastLineTemptFileInputDelimited_2;
							}

							csvReadertFileInputDelimited_2.close();
							if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {
								csvReadertFileInputDelimited_2 = new com.talend.csv.CSVReader(
										(java.io.InputStream) filename_tFileInputDelimited_2,
										fieldSeparator_tFileInputDelimited_2[0], "UTF-8");
							} else {
								csvReadertFileInputDelimited_2 = new com.talend.csv.CSVReader(
										String.valueOf(filename_tFileInputDelimited_2),
										fieldSeparator_tFileInputDelimited_2[0], "UTF-8");
							}
							csvReadertFileInputDelimited_2.setTrimWhitespace(false);
							if ((rowSeparator_tFileInputDelimited_2[0] != '\n')
									&& (rowSeparator_tFileInputDelimited_2[0] != '\r'))
								csvReadertFileInputDelimited_2.setLineEnd("" + rowSeparator_tFileInputDelimited_2[0]);

							csvReadertFileInputDelimited_2.setQuoteChar('"');

							csvReadertFileInputDelimited_2.setEscapeChar(csvReadertFileInputDelimited_2.getQuoteChar());

						}

						if (limittFileInputDelimited_2 != 0) {
							for (currentLinetFileInputDelimited_2 = 0; currentLinetFileInputDelimited_2 < 1; currentLinetFileInputDelimited_2++) {
								csvReadertFileInputDelimited_2.readNext();
							}
						}
						csvReadertFileInputDelimited_2.setSkipEmptyRecords(false);

					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					} // TD110 end

					while (limittFileInputDelimited_2 != 0 && csvReadertFileInputDelimited_2 != null
							&& csvReadertFileInputDelimited_2.readNext()) {
						rowstate_tFileInputDelimited_2.reset();

						rowtFileInputDelimited_2 = csvReadertFileInputDelimited_2.getValues();

						currentLinetFileInputDelimited_2++;

						if (lastLinetFileInputDelimited_2 > -1
								&& currentLinetFileInputDelimited_2 > lastLinetFileInputDelimited_2) {
							break;
						}
						outputLinetFileInputDelimited_2++;
						if (limittFileInputDelimited_2 > 0
								&& outputLinetFileInputDelimited_2 > limittFileInputDelimited_2) {
							break;
						}

						row3 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row3 = new row3Struct();
						try {

							char fieldSeparator_tFileInputDelimited_2_ListType[] = null;
							// support passing value (property: Field Separator) by 'context.fs' or
							// 'globalMap.get("fs")'.
							if (((String) ",").length() > 0) {
								fieldSeparator_tFileInputDelimited_2_ListType = ((String) ",").toCharArray();
							} else {
								throw new IllegalArgumentException("Field Separator must be assigned a char.");
							}
							if (rowtFileInputDelimited_2.length == 1 && ("\015").equals(rowtFileInputDelimited_2[0])) {// empty
																														// line
																														// when
																														// row
																														// separator
																														// is
																														// '\n'

								row3.CAMIS = null;

								row3.DBA = null;

								row3.BORO = null;

								row3.BUILDING = null;

								row3.STREET = null;

								row3.ZIPCODE = null;

								row3.PHONE = null;

								row3.CUISINE_DESCRIPTION = null;

								row3.INSPECTION_DATE = null;

								row3.ACTION = null;

								row3.VIOLATION_CODE = null;

								row3.VIOLATION_DESCRIPTION = null;

								row3.CRITICAL_FLAG = null;

								row3.SCORE = null;

								row3.GRADE = null;

								row3.GRADE_DATE = null;

								row3.RECORD_DATE = null;

								row3.INSPECTION_TYPE = null;

							} else {

								int columnIndexWithD_tFileInputDelimited_2 = 0; // Column Index

								columnIndexWithD_tFileInputDelimited_2 = 0;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									if (rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2].length() > 0) {
										try {

											row3.CAMIS = ParserUtils.parseTo_Integer(
													rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2]);

										} catch (java.lang.Exception ex_tFileInputDelimited_2) {
											globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
													ex_tFileInputDelimited_2.getMessage());
											rowstate_tFileInputDelimited_2.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"CAMIS", "row3",
															rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2],
															ex_tFileInputDelimited_2),
													ex_tFileInputDelimited_2));
										}
									} else {

										row3.CAMIS = null;

									}

								} else {

									row3.CAMIS = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 1;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.DBA = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.DBA = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 2;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.BORO = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.BORO = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 3;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.BUILDING = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.BUILDING = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 4;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.STREET = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.STREET = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 5;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.ZIPCODE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.ZIPCODE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 6;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									if (rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2].length() > 0) {
										try {

											row3.PHONE = ParserUtils.parseTo_Long(
													rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2]);

										} catch (java.lang.Exception ex_tFileInputDelimited_2) {
											globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
													ex_tFileInputDelimited_2.getMessage());
											rowstate_tFileInputDelimited_2.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"PHONE", "row3",
															rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2],
															ex_tFileInputDelimited_2),
													ex_tFileInputDelimited_2));
										}
									} else {

										row3.PHONE = null;

									}

								} else {

									row3.PHONE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 7;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.CUISINE_DESCRIPTION = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.CUISINE_DESCRIPTION = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 8;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.INSPECTION_DATE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.INSPECTION_DATE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 9;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.ACTION = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.ACTION = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 10;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.VIOLATION_CODE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.VIOLATION_CODE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 11;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.VIOLATION_DESCRIPTION = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.VIOLATION_DESCRIPTION = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 12;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.CRITICAL_FLAG = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.CRITICAL_FLAG = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 13;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.SCORE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.SCORE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 14;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.GRADE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.GRADE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 15;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.GRADE_DATE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.GRADE_DATE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 16;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.RECORD_DATE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.RECORD_DATE = null;

								}

								columnIndexWithD_tFileInputDelimited_2 = 17;

								if (columnIndexWithD_tFileInputDelimited_2 < rowtFileInputDelimited_2.length) {

									row3.INSPECTION_TYPE = rowtFileInputDelimited_2[columnIndexWithD_tFileInputDelimited_2];

								} else {

									row3.INSPECTION_TYPE = null;

								}

							}

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							System.err.println(e.getMessage());
							row3 = null;

							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						}

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "row3"
						if (row3 != null) {

							/**
							 * [tLogRow_3 main ] start
							 */

							currentComponent = "tLogRow_3";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							row4 = row3;

							tos_count_tLogRow_3++;

							/**
							 * [tLogRow_3 main ] stop
							 */

							/**
							 * [tLogRow_3 process_data_begin ] start
							 */

							currentComponent = "tLogRow_3";

							/**
							 * [tLogRow_3 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row4 main ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row4"

								);
							}

							row4Struct row4_HashRow = new row4Struct();

							row4_HashRow.CAMIS = row4.CAMIS;

							row4_HashRow.DBA = row4.DBA;

							row4_HashRow.BORO = row4.BORO;

							row4_HashRow.BUILDING = row4.BUILDING;

							row4_HashRow.STREET = row4.STREET;

							row4_HashRow.ZIPCODE = row4.ZIPCODE;

							row4_HashRow.PHONE = row4.PHONE;

							row4_HashRow.CUISINE_DESCRIPTION = row4.CUISINE_DESCRIPTION;

							row4_HashRow.INSPECTION_DATE = row4.INSPECTION_DATE;

							row4_HashRow.ACTION = row4.ACTION;

							row4_HashRow.VIOLATION_CODE = row4.VIOLATION_CODE;

							row4_HashRow.VIOLATION_DESCRIPTION = row4.VIOLATION_DESCRIPTION;

							row4_HashRow.CRITICAL_FLAG = row4.CRITICAL_FLAG;

							row4_HashRow.SCORE = row4.SCORE;

							row4_HashRow.GRADE = row4.GRADE;

							row4_HashRow.GRADE_DATE = row4.GRADE_DATE;

							row4_HashRow.RECORD_DATE = row4.RECORD_DATE;

							row4_HashRow.INSPECTION_TYPE = row4.INSPECTION_TYPE;

							tHash_Lookup_row4.put(row4_HashRow);

							tos_count_tAdvancedHash_row4++;

							/**
							 * [tAdvancedHash_row4 main ] stop
							 */

							/**
							 * [tAdvancedHash_row4 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							/**
							 * [tAdvancedHash_row4 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row4 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row4";

							/**
							 * [tAdvancedHash_row4 process_data_end ] stop
							 */

							/**
							 * [tLogRow_3 process_data_end ] start
							 */

							currentComponent = "tLogRow_3";

							/**
							 * [tLogRow_3 process_data_end ] stop
							 */

						} // End of branch "row3"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						nb_line_tFileInputDelimited_2++;
					}

				} finally {
					if (!(filename_tFileInputDelimited_2 instanceof java.io.InputStream)) {
						if (csvReadertFileInputDelimited_2 != null) {
							csvReadertFileInputDelimited_2.close();
						}
					}
					if (csvReadertFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", nb_line_tFileInputDelimited_2);
					}

				}

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tLogRow_3 end ] start
				 */

				currentComponent = "tLogRow_3";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tLogRow_3", true);
				end_Hash.put("tLogRow_3", System.currentTimeMillis());

				/**
				 * [tLogRow_3 end ] stop
				 */

				/**
				 * [tAdvancedHash_row4 end ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				tHash_Lookup_row4.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tAdvancedHash_row4", true);
				end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tLogRow_3 finally ] start
				 */

				currentComponent = "tLogRow_3";

				/**
				 * [tLogRow_3 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row4 finally ] start
				 */

				currentComponent = "tAdvancedHash_row4";

				/**
				 * [tAdvancedHash_row4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public void tFileInputDelimited_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tFileInputDelimited_3 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_3", false);
				start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_3";

				int tos_count_tFileInputDelimited_3 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_3 = 0;
				int footer_tFileInputDelimited_3 = 0;
				int totalLinetFileInputDelimited_3 = 0;
				int limittFileInputDelimited_3 = 200;
				int lastLinetFileInputDelimited_3 = -1;

				char fieldSeparator_tFileInputDelimited_3[] = null;

				// support passing value (property: Field Separator) by 'context.fs' or
				// 'globalMap.get("fs")'.
				if (((String) ",").length() > 0) {
					fieldSeparator_tFileInputDelimited_3 = ((String) ",").toCharArray();
				} else {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_3[] = null;

				// support passing value (property: Row Separator) by 'context.rs' or
				// 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_3 = ((String) "\n").toCharArray();
				} else {
					throw new IllegalArgumentException("Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_3 = /** Start field tFileInputDelimited_3:FILENAME */
						"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/AirBNB2.csv"/**
																											 * End field
																											 * tFileInputDelimited_3:FILENAME
																											 */
				;
				com.talend.csv.CSVReader csvReadertFileInputDelimited_3 = null;

				try {

					String[] rowtFileInputDelimited_3 = null;
					int currentLinetFileInputDelimited_3 = 0;
					int outputLinetFileInputDelimited_3 = 0;
					try {// TD110 begin
						if (filename_tFileInputDelimited_3 instanceof java.io.InputStream) {

							int footer_value_tFileInputDelimited_3 = 0;
							if (footer_value_tFileInputDelimited_3 > 0) {
								throw new java.lang.Exception(
										"When the input source is a stream,footer shouldn't be bigger than 0.");
							}

							csvReadertFileInputDelimited_3 = new com.talend.csv.CSVReader(
									(java.io.InputStream) filename_tFileInputDelimited_3,
									fieldSeparator_tFileInputDelimited_3[0], "UTF-8");
						} else {
							csvReadertFileInputDelimited_3 = new com.talend.csv.CSVReader(
									String.valueOf(filename_tFileInputDelimited_3),
									fieldSeparator_tFileInputDelimited_3[0], "UTF-8");
						}

						csvReadertFileInputDelimited_3.setTrimWhitespace(false);
						if ((rowSeparator_tFileInputDelimited_3[0] != '\n')
								&& (rowSeparator_tFileInputDelimited_3[0] != '\r'))
							csvReadertFileInputDelimited_3.setLineEnd("" + rowSeparator_tFileInputDelimited_3[0]);

						csvReadertFileInputDelimited_3.setQuoteChar('"');

						csvReadertFileInputDelimited_3.setEscapeChar(csvReadertFileInputDelimited_3.getQuoteChar());

						if (footer_tFileInputDelimited_3 > 0) {
							for (totalLinetFileInputDelimited_3 = 0; totalLinetFileInputDelimited_3 < 1; totalLinetFileInputDelimited_3++) {
								csvReadertFileInputDelimited_3.readNext();
							}
							csvReadertFileInputDelimited_3.setSkipEmptyRecords(false);
							while (csvReadertFileInputDelimited_3.readNext()) {

								totalLinetFileInputDelimited_3++;

							}
							int lastLineTemptFileInputDelimited_3 = totalLinetFileInputDelimited_3
									- footer_tFileInputDelimited_3 < 0 ? 0
											: totalLinetFileInputDelimited_3 - footer_tFileInputDelimited_3;
							if (lastLinetFileInputDelimited_3 > 0) {
								lastLinetFileInputDelimited_3 = lastLinetFileInputDelimited_3 < lastLineTemptFileInputDelimited_3
										? lastLinetFileInputDelimited_3
										: lastLineTemptFileInputDelimited_3;
							} else {
								lastLinetFileInputDelimited_3 = lastLineTemptFileInputDelimited_3;
							}

							csvReadertFileInputDelimited_3.close();
							if (filename_tFileInputDelimited_3 instanceof java.io.InputStream) {
								csvReadertFileInputDelimited_3 = new com.talend.csv.CSVReader(
										(java.io.InputStream) filename_tFileInputDelimited_3,
										fieldSeparator_tFileInputDelimited_3[0], "UTF-8");
							} else {
								csvReadertFileInputDelimited_3 = new com.talend.csv.CSVReader(
										String.valueOf(filename_tFileInputDelimited_3),
										fieldSeparator_tFileInputDelimited_3[0], "UTF-8");
							}
							csvReadertFileInputDelimited_3.setTrimWhitespace(false);
							if ((rowSeparator_tFileInputDelimited_3[0] != '\n')
									&& (rowSeparator_tFileInputDelimited_3[0] != '\r'))
								csvReadertFileInputDelimited_3.setLineEnd("" + rowSeparator_tFileInputDelimited_3[0]);

							csvReadertFileInputDelimited_3.setQuoteChar('"');

							csvReadertFileInputDelimited_3.setEscapeChar(csvReadertFileInputDelimited_3.getQuoteChar());

						}

						if (limittFileInputDelimited_3 != 0) {
							for (currentLinetFileInputDelimited_3 = 0; currentLinetFileInputDelimited_3 < 1; currentLinetFileInputDelimited_3++) {
								csvReadertFileInputDelimited_3.readNext();
							}
						}
						csvReadertFileInputDelimited_3.setSkipEmptyRecords(false);

					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					} // TD110 end

					while (limittFileInputDelimited_3 != 0 && csvReadertFileInputDelimited_3 != null
							&& csvReadertFileInputDelimited_3.readNext()) {
						rowstate_tFileInputDelimited_3.reset();

						rowtFileInputDelimited_3 = csvReadertFileInputDelimited_3.getValues();

						currentLinetFileInputDelimited_3++;

						if (lastLinetFileInputDelimited_3 > -1
								&& currentLinetFileInputDelimited_3 > lastLinetFileInputDelimited_3) {
							break;
						}
						outputLinetFileInputDelimited_3++;
						if (limittFileInputDelimited_3 > 0
								&& outputLinetFileInputDelimited_3 > limittFileInputDelimited_3) {
							break;
						}

						/**
						 * [tFileInputDelimited_3 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_3 main ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						tos_count_tFileInputDelimited_3++;

						/**
						 * [tFileInputDelimited_3 main ] stop
						 */

						/**
						 * [tFileInputDelimited_3 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_begin ] stop
						 */

						/**
						 * [tFileInputDelimited_3 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_3 end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						nb_line_tFileInputDelimited_3++;
					}

				} finally {
					if (!(filename_tFileInputDelimited_3 instanceof java.io.InputStream)) {
						if (csvReadertFileInputDelimited_3 != null) {
							csvReadertFileInputDelimited_3.close();
						}
					}
					if (csvReadertFileInputDelimited_3 != null) {
						globalMap.put("tFileInputDelimited_3_NB_LINE", nb_line_tFileInputDelimited_3);
					}

				}

				ok_Hash.put("tFileInputDelimited_3", true);
				end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_3 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_3 finally ] start
				 */

				currentComponent = "tFileInputDelimited_3";

				/**
				 * [tFileInputDelimited_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 1);
	}

	public void tFileInputDelimited_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tFileInputDelimited_4 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_4", false);
				start_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_4";

				int tos_count_tFileInputDelimited_4 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_4 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_4 = 0;
				int footer_tFileInputDelimited_4 = 0;
				int totalLinetFileInputDelimited_4 = 0;
				int limittFileInputDelimited_4 = 200;
				int lastLinetFileInputDelimited_4 = -1;

				char fieldSeparator_tFileInputDelimited_4[] = null;

				// support passing value (property: Field Separator) by 'context.fs' or
				// 'globalMap.get("fs")'.
				if (((String) ",").length() > 0) {
					fieldSeparator_tFileInputDelimited_4 = ((String) ",").toCharArray();
				} else {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_4[] = null;

				// support passing value (property: Row Separator) by 'context.rs' or
				// 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_4 = ((String) "\n").toCharArray();
				} else {
					throw new IllegalArgumentException("Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_4 = /** Start field tFileInputDelimited_4:FILENAME */
						"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/CrimeData.csv"/**
																											 * End field
																											 * tFileInputDelimited_4:FILENAME
																											 */
				;
				com.talend.csv.CSVReader csvReadertFileInputDelimited_4 = null;

				try {

					String[] rowtFileInputDelimited_4 = null;
					int currentLinetFileInputDelimited_4 = 0;
					int outputLinetFileInputDelimited_4 = 0;
					try {// TD110 begin
						if (filename_tFileInputDelimited_4 instanceof java.io.InputStream) {

							int footer_value_tFileInputDelimited_4 = 0;
							if (footer_value_tFileInputDelimited_4 > 0) {
								throw new java.lang.Exception(
										"When the input source is a stream,footer shouldn't be bigger than 0.");
							}

							csvReadertFileInputDelimited_4 = new com.talend.csv.CSVReader(
									(java.io.InputStream) filename_tFileInputDelimited_4,
									fieldSeparator_tFileInputDelimited_4[0], "US-ASCII");
						} else {
							csvReadertFileInputDelimited_4 = new com.talend.csv.CSVReader(
									String.valueOf(filename_tFileInputDelimited_4),
									fieldSeparator_tFileInputDelimited_4[0], "US-ASCII");
						}

						csvReadertFileInputDelimited_4.setTrimWhitespace(false);
						if ((rowSeparator_tFileInputDelimited_4[0] != '\n')
								&& (rowSeparator_tFileInputDelimited_4[0] != '\r'))
							csvReadertFileInputDelimited_4.setLineEnd("" + rowSeparator_tFileInputDelimited_4[0]);

						csvReadertFileInputDelimited_4.setQuoteChar('"');

						csvReadertFileInputDelimited_4.setEscapeChar(csvReadertFileInputDelimited_4.getQuoteChar());

						if (footer_tFileInputDelimited_4 > 0) {
							for (totalLinetFileInputDelimited_4 = 0; totalLinetFileInputDelimited_4 < 1; totalLinetFileInputDelimited_4++) {
								csvReadertFileInputDelimited_4.readNext();
							}
							csvReadertFileInputDelimited_4.setSkipEmptyRecords(false);
							while (csvReadertFileInputDelimited_4.readNext()) {

								totalLinetFileInputDelimited_4++;

							}
							int lastLineTemptFileInputDelimited_4 = totalLinetFileInputDelimited_4
									- footer_tFileInputDelimited_4 < 0 ? 0
											: totalLinetFileInputDelimited_4 - footer_tFileInputDelimited_4;
							if (lastLinetFileInputDelimited_4 > 0) {
								lastLinetFileInputDelimited_4 = lastLinetFileInputDelimited_4 < lastLineTemptFileInputDelimited_4
										? lastLinetFileInputDelimited_4
										: lastLineTemptFileInputDelimited_4;
							} else {
								lastLinetFileInputDelimited_4 = lastLineTemptFileInputDelimited_4;
							}

							csvReadertFileInputDelimited_4.close();
							if (filename_tFileInputDelimited_4 instanceof java.io.InputStream) {
								csvReadertFileInputDelimited_4 = new com.talend.csv.CSVReader(
										(java.io.InputStream) filename_tFileInputDelimited_4,
										fieldSeparator_tFileInputDelimited_4[0], "US-ASCII");
							} else {
								csvReadertFileInputDelimited_4 = new com.talend.csv.CSVReader(
										String.valueOf(filename_tFileInputDelimited_4),
										fieldSeparator_tFileInputDelimited_4[0], "US-ASCII");
							}
							csvReadertFileInputDelimited_4.setTrimWhitespace(false);
							if ((rowSeparator_tFileInputDelimited_4[0] != '\n')
									&& (rowSeparator_tFileInputDelimited_4[0] != '\r'))
								csvReadertFileInputDelimited_4.setLineEnd("" + rowSeparator_tFileInputDelimited_4[0]);

							csvReadertFileInputDelimited_4.setQuoteChar('"');

							csvReadertFileInputDelimited_4.setEscapeChar(csvReadertFileInputDelimited_4.getQuoteChar());

						}

						if (limittFileInputDelimited_4 != 0) {
							for (currentLinetFileInputDelimited_4 = 0; currentLinetFileInputDelimited_4 < 1; currentLinetFileInputDelimited_4++) {
								csvReadertFileInputDelimited_4.readNext();
							}
						}
						csvReadertFileInputDelimited_4.setSkipEmptyRecords(false);

					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					} // TD110 end

					while (limittFileInputDelimited_4 != 0 && csvReadertFileInputDelimited_4 != null
							&& csvReadertFileInputDelimited_4.readNext()) {
						rowstate_tFileInputDelimited_4.reset();

						rowtFileInputDelimited_4 = csvReadertFileInputDelimited_4.getValues();

						currentLinetFileInputDelimited_4++;

						if (lastLinetFileInputDelimited_4 > -1
								&& currentLinetFileInputDelimited_4 > lastLinetFileInputDelimited_4) {
							break;
						}
						outputLinetFileInputDelimited_4++;
						if (limittFileInputDelimited_4 > 0
								&& outputLinetFileInputDelimited_4 > limittFileInputDelimited_4) {
							break;
						}

						/**
						 * [tFileInputDelimited_4 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_4 main ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						tos_count_tFileInputDelimited_4++;

						/**
						 * [tFileInputDelimited_4 main ] stop
						 */

						/**
						 * [tFileInputDelimited_4 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						/**
						 * [tFileInputDelimited_4 process_data_begin ] stop
						 */

						/**
						 * [tFileInputDelimited_4 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						/**
						 * [tFileInputDelimited_4 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_4 end ] start
						 */

						currentComponent = "tFileInputDelimited_4";

						nb_line_tFileInputDelimited_4++;
					}

				} finally {
					if (!(filename_tFileInputDelimited_4 instanceof java.io.InputStream)) {
						if (csvReadertFileInputDelimited_4 != null) {
							csvReadertFileInputDelimited_4.close();
						}
					}
					if (csvReadertFileInputDelimited_4 != null) {
						globalMap.put("tFileInputDelimited_4_NB_LINE", nb_line_tFileInputDelimited_4);
					}

				}

				ok_Hash.put("tFileInputDelimited_4", true);
				end_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_4 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_4 finally ] start
				 */

				currentComponent = "tFileInputDelimited_4";

				/**
				 * [tFileInputDelimited_4 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 1);
	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Long CensusTract;

		public Long getCensusTract() {
			return this.CensusTract;
		}

		public String County;

		public String getCounty() {
			return this.County;
		}

		public String Borough;

		public String getBorough() {
			return this.Borough;
		}

		public Integer TotalPop;

		public Integer getTotalPop() {
			return this.TotalPop;
		}

		public Integer Men;

		public Integer getMen() {
			return this.Men;
		}

		public Integer Women;

		public Integer getWomen() {
			return this.Women;
		}

		public Float Hispanic;

		public Float getHispanic() {
			return this.Hispanic;
		}

		public Float White;

		public Float getWhite() {
			return this.White;
		}

		public Float Black;

		public Float getBlack() {
			return this.Black;
		}

		public Float Native;

		public Float getNative() {
			return this.Native;
		}

		public Float Asian;

		public Float getAsian() {
			return this.Asian;
		}

		public Integer Citizen;

		public Integer getCitizen() {
			return this.Citizen;
		}

		public String Income;

		public String getIncome() {
			return this.Income;
		}

		public String IncomeErr;

		public String getIncomeErr() {
			return this.IncomeErr;
		}

		public Float IncomePerCap;

		public Float getIncomePerCap() {
			return this.IncomePerCap;
		}

		public Float IncomePerCapErr;

		public Float getIncomePerCapErr() {
			return this.IncomePerCapErr;
		}

		public String Poverty;

		public String getPoverty() {
			return this.Poverty;
		}

		public String ChildPoverty;

		public String getChildPoverty() {
			return this.ChildPoverty;
		}

		public String Professional;

		public String getProfessional() {
			return this.Professional;
		}

		public String Service;

		public String getService() {
			return this.Service;
		}

		public String Office;

		public String getOffice() {
			return this.Office;
		}

		public String Construction;

		public String getConstruction() {
			return this.Construction;
		}

		public String Production;

		public String getProduction() {
			return this.Production;
		}

		public String Drive;

		public String getDrive() {
			return this.Drive;
		}

		public String Carpool;

		public String getCarpool() {
			return this.Carpool;
		}

		public String Transit;

		public String getTransit() {
			return this.Transit;
		}

		public String Walk;

		public String getWalk() {
			return this.Walk;
		}

		public String OtherTransp;

		public String getOtherTransp() {
			return this.OtherTransp;
		}

		public String WorkAtHome;

		public String getWorkAtHome() {
			return this.WorkAtHome;
		}

		public String MeanCommute;

		public String getMeanCommute() {
			return this.MeanCommute;
		}

		public Integer Employed;

		public Integer getEmployed() {
			return this.Employed;
		}

		public String PrivateWork;

		public String getPrivateWork() {
			return this.PrivateWork;
		}

		public String PublicWork;

		public String getPublicWork() {
			return this.PublicWork;
		}

		public String SelfEmployed;

		public String getSelfEmployed() {
			return this.SelfEmployed;
		}

		public String FamilyWork;

		public String getFamilyWork() {
			return this.FamilyWork;
		}

		public String Unemployment;

		public String getUnemployment() {
			return this.Unemployment;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CensusTract=" + String.valueOf(CensusTract));
			sb.append(",County=" + County);
			sb.append(",Borough=" + Borough);
			sb.append(",TotalPop=" + String.valueOf(TotalPop));
			sb.append(",Men=" + String.valueOf(Men));
			sb.append(",Women=" + String.valueOf(Women));
			sb.append(",Hispanic=" + String.valueOf(Hispanic));
			sb.append(",White=" + String.valueOf(White));
			sb.append(",Black=" + String.valueOf(Black));
			sb.append(",Native=" + String.valueOf(Native));
			sb.append(",Asian=" + String.valueOf(Asian));
			sb.append(",Citizen=" + String.valueOf(Citizen));
			sb.append(",Income=" + Income);
			sb.append(",IncomeErr=" + IncomeErr);
			sb.append(",IncomePerCap=" + String.valueOf(IncomePerCap));
			sb.append(",IncomePerCapErr=" + String.valueOf(IncomePerCapErr));
			sb.append(",Poverty=" + Poverty);
			sb.append(",ChildPoverty=" + ChildPoverty);
			sb.append(",Professional=" + Professional);
			sb.append(",Service=" + Service);
			sb.append(",Office=" + Office);
			sb.append(",Construction=" + Construction);
			sb.append(",Production=" + Production);
			sb.append(",Drive=" + Drive);
			sb.append(",Carpool=" + Carpool);
			sb.append(",Transit=" + Transit);
			sb.append(",Walk=" + Walk);
			sb.append(",OtherTransp=" + OtherTransp);
			sb.append(",WorkAtHome=" + WorkAtHome);
			sb.append(",MeanCommute=" + MeanCommute);
			sb.append(",Employed=" + String.valueOf(Employed));
			sb.append(",PrivateWork=" + PrivateWork);
			sb.append(",PublicWork=" + PublicWork);
			sb.append(",SelfEmployed=" + SelfEmployed);
			sb.append(",FamilyWork=" + FamilyWork);
			sb.append(",Unemployment=" + Unemployment);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Long CensusTract;

		public Long getCensusTract() {
			return this.CensusTract;
		}

		public String County;

		public String getCounty() {
			return this.County;
		}

		public String Borough;

		public String getBorough() {
			return this.Borough;
		}

		public Integer TotalPop;

		public Integer getTotalPop() {
			return this.TotalPop;
		}

		public Integer Men;

		public Integer getMen() {
			return this.Men;
		}

		public Integer Women;

		public Integer getWomen() {
			return this.Women;
		}

		public Float Hispanic;

		public Float getHispanic() {
			return this.Hispanic;
		}

		public Float White;

		public Float getWhite() {
			return this.White;
		}

		public Float Black;

		public Float getBlack() {
			return this.Black;
		}

		public Float Native;

		public Float getNative() {
			return this.Native;
		}

		public Float Asian;

		public Float getAsian() {
			return this.Asian;
		}

		public Integer Citizen;

		public Integer getCitizen() {
			return this.Citizen;
		}

		public String Income;

		public String getIncome() {
			return this.Income;
		}

		public String IncomeErr;

		public String getIncomeErr() {
			return this.IncomeErr;
		}

		public Float IncomePerCap;

		public Float getIncomePerCap() {
			return this.IncomePerCap;
		}

		public Float IncomePerCapErr;

		public Float getIncomePerCapErr() {
			return this.IncomePerCapErr;
		}

		public String Poverty;

		public String getPoverty() {
			return this.Poverty;
		}

		public String ChildPoverty;

		public String getChildPoverty() {
			return this.ChildPoverty;
		}

		public String Professional;

		public String getProfessional() {
			return this.Professional;
		}

		public String Service;

		public String getService() {
			return this.Service;
		}

		public String Office;

		public String getOffice() {
			return this.Office;
		}

		public String Construction;

		public String getConstruction() {
			return this.Construction;
		}

		public String Production;

		public String getProduction() {
			return this.Production;
		}

		public String Drive;

		public String getDrive() {
			return this.Drive;
		}

		public String Carpool;

		public String getCarpool() {
			return this.Carpool;
		}

		public String Transit;

		public String getTransit() {
			return this.Transit;
		}

		public String Walk;

		public String getWalk() {
			return this.Walk;
		}

		public String OtherTransp;

		public String getOtherTransp() {
			return this.OtherTransp;
		}

		public String WorkAtHome;

		public String getWorkAtHome() {
			return this.WorkAtHome;
		}

		public String MeanCommute;

		public String getMeanCommute() {
			return this.MeanCommute;
		}

		public Integer Employed;

		public Integer getEmployed() {
			return this.Employed;
		}

		public String PrivateWork;

		public String getPrivateWork() {
			return this.PrivateWork;
		}

		public String PublicWork;

		public String getPublicWork() {
			return this.PublicWork;
		}

		public String SelfEmployed;

		public String getSelfEmployed() {
			return this.SelfEmployed;
		}

		public String FamilyWork;

		public String getFamilyWork() {
			return this.FamilyWork;
		}

		public String Unemployment;

		public String getUnemployment() {
			return this.Unemployment;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CensusTract=" + String.valueOf(CensusTract));
			sb.append(",County=" + County);
			sb.append(",Borough=" + Borough);
			sb.append(",TotalPop=" + String.valueOf(TotalPop));
			sb.append(",Men=" + String.valueOf(Men));
			sb.append(",Women=" + String.valueOf(Women));
			sb.append(",Hispanic=" + String.valueOf(Hispanic));
			sb.append(",White=" + String.valueOf(White));
			sb.append(",Black=" + String.valueOf(Black));
			sb.append(",Native=" + String.valueOf(Native));
			sb.append(",Asian=" + String.valueOf(Asian));
			sb.append(",Citizen=" + String.valueOf(Citizen));
			sb.append(",Income=" + Income);
			sb.append(",IncomeErr=" + IncomeErr);
			sb.append(",IncomePerCap=" + String.valueOf(IncomePerCap));
			sb.append(",IncomePerCapErr=" + String.valueOf(IncomePerCapErr));
			sb.append(",Poverty=" + Poverty);
			sb.append(",ChildPoverty=" + ChildPoverty);
			sb.append(",Professional=" + Professional);
			sb.append(",Service=" + Service);
			sb.append(",Office=" + Office);
			sb.append(",Construction=" + Construction);
			sb.append(",Production=" + Production);
			sb.append(",Drive=" + Drive);
			sb.append(",Carpool=" + Carpool);
			sb.append(",Transit=" + Transit);
			sb.append(",Walk=" + Walk);
			sb.append(",OtherTransp=" + OtherTransp);
			sb.append(",WorkAtHome=" + WorkAtHome);
			sb.append(",MeanCommute=" + MeanCommute);
			sb.append(",Employed=" + String.valueOf(Employed));
			sb.append(",PrivateWork=" + PrivateWork);
			sb.append(",PublicWork=" + PublicWork);
			sb.append(",SelfEmployed=" + SelfEmployed);
			sb.append(",FamilyWork=" + FamilyWork);
			sb.append(",Unemployment=" + Unemployment);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputDelimited_5Struct
			implements routines.system.IPersistableRow<after_tFileInputDelimited_5Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Long CensusTract;

		public Long getCensusTract() {
			return this.CensusTract;
		}

		public String County;

		public String getCounty() {
			return this.County;
		}

		public String Borough;

		public String getBorough() {
			return this.Borough;
		}

		public Integer TotalPop;

		public Integer getTotalPop() {
			return this.TotalPop;
		}

		public Integer Men;

		public Integer getMen() {
			return this.Men;
		}

		public Integer Women;

		public Integer getWomen() {
			return this.Women;
		}

		public Float Hispanic;

		public Float getHispanic() {
			return this.Hispanic;
		}

		public Float White;

		public Float getWhite() {
			return this.White;
		}

		public Float Black;

		public Float getBlack() {
			return this.Black;
		}

		public Float Native;

		public Float getNative() {
			return this.Native;
		}

		public Float Asian;

		public Float getAsian() {
			return this.Asian;
		}

		public Integer Citizen;

		public Integer getCitizen() {
			return this.Citizen;
		}

		public String Income;

		public String getIncome() {
			return this.Income;
		}

		public String IncomeErr;

		public String getIncomeErr() {
			return this.IncomeErr;
		}

		public Float IncomePerCap;

		public Float getIncomePerCap() {
			return this.IncomePerCap;
		}

		public Float IncomePerCapErr;

		public Float getIncomePerCapErr() {
			return this.IncomePerCapErr;
		}

		public String Poverty;

		public String getPoverty() {
			return this.Poverty;
		}

		public String ChildPoverty;

		public String getChildPoverty() {
			return this.ChildPoverty;
		}

		public String Professional;

		public String getProfessional() {
			return this.Professional;
		}

		public String Service;

		public String getService() {
			return this.Service;
		}

		public String Office;

		public String getOffice() {
			return this.Office;
		}

		public String Construction;

		public String getConstruction() {
			return this.Construction;
		}

		public String Production;

		public String getProduction() {
			return this.Production;
		}

		public String Drive;

		public String getDrive() {
			return this.Drive;
		}

		public String Carpool;

		public String getCarpool() {
			return this.Carpool;
		}

		public String Transit;

		public String getTransit() {
			return this.Transit;
		}

		public String Walk;

		public String getWalk() {
			return this.Walk;
		}

		public String OtherTransp;

		public String getOtherTransp() {
			return this.OtherTransp;
		}

		public String WorkAtHome;

		public String getWorkAtHome() {
			return this.WorkAtHome;
		}

		public String MeanCommute;

		public String getMeanCommute() {
			return this.MeanCommute;
		}

		public Integer Employed;

		public Integer getEmployed() {
			return this.Employed;
		}

		public String PrivateWork;

		public String getPrivateWork() {
			return this.PrivateWork;
		}

		public String PublicWork;

		public String getPublicWork() {
			return this.PublicWork;
		}

		public String SelfEmployed;

		public String getSelfEmployed() {
			return this.SelfEmployed;
		}

		public String FamilyWork;

		public String getFamilyWork() {
			return this.FamilyWork;
		}

		public String Unemployment;

		public String getUnemployment() {
			return this.Unemployment;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CensusTract = null;
					} else {
						this.CensusTract = dis.readLong();
					}

					this.County = readString(dis);

					this.Borough = readString(dis);

					this.TotalPop = readInteger(dis);

					this.Men = readInteger(dis);

					this.Women = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Hispanic = null;
					} else {
						this.Hispanic = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.White = null;
					} else {
						this.White = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Black = null;
					} else {
						this.Black = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Native = null;
					} else {
						this.Native = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Asian = null;
					} else {
						this.Asian = dis.readFloat();
					}

					this.Citizen = readInteger(dis);

					this.Income = readString(dis);

					this.IncomeErr = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCap = null;
					} else {
						this.IncomePerCap = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.IncomePerCapErr = null;
					} else {
						this.IncomePerCapErr = dis.readFloat();
					}

					this.Poverty = readString(dis);

					this.ChildPoverty = readString(dis);

					this.Professional = readString(dis);

					this.Service = readString(dis);

					this.Office = readString(dis);

					this.Construction = readString(dis);

					this.Production = readString(dis);

					this.Drive = readString(dis);

					this.Carpool = readString(dis);

					this.Transit = readString(dis);

					this.Walk = readString(dis);

					this.OtherTransp = readString(dis);

					this.WorkAtHome = readString(dis);

					this.MeanCommute = readString(dis);

					this.Employed = readInteger(dis);

					this.PrivateWork = readString(dis);

					this.PublicWork = readString(dis);

					this.SelfEmployed = readString(dis);

					this.FamilyWork = readString(dis);

					this.Unemployment = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Long

				if (this.CensusTract == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CensusTract);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.Borough, dos);

				// Integer

				writeInteger(this.TotalPop, dos);

				// Integer

				writeInteger(this.Men, dos);

				// Integer

				writeInteger(this.Women, dos);

				// Float

				if (this.Hispanic == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Hispanic);
				}

				// Float

				if (this.White == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.White);
				}

				// Float

				if (this.Black == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Black);
				}

				// Float

				if (this.Native == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Native);
				}

				// Float

				if (this.Asian == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Asian);
				}

				// Integer

				writeInteger(this.Citizen, dos);

				// String

				writeString(this.Income, dos);

				// String

				writeString(this.IncomeErr, dos);

				// Float

				if (this.IncomePerCap == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCap);
				}

				// Float

				if (this.IncomePerCapErr == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.IncomePerCapErr);
				}

				// String

				writeString(this.Poverty, dos);

				// String

				writeString(this.ChildPoverty, dos);

				// String

				writeString(this.Professional, dos);

				// String

				writeString(this.Service, dos);

				// String

				writeString(this.Office, dos);

				// String

				writeString(this.Construction, dos);

				// String

				writeString(this.Production, dos);

				// String

				writeString(this.Drive, dos);

				// String

				writeString(this.Carpool, dos);

				// String

				writeString(this.Transit, dos);

				// String

				writeString(this.Walk, dos);

				// String

				writeString(this.OtherTransp, dos);

				// String

				writeString(this.WorkAtHome, dos);

				// String

				writeString(this.MeanCommute, dos);

				// Integer

				writeInteger(this.Employed, dos);

				// String

				writeString(this.PrivateWork, dos);

				// String

				writeString(this.PublicWork, dos);

				// String

				writeString(this.SelfEmployed, dos);

				// String

				writeString(this.FamilyWork, dos);

				// String

				writeString(this.Unemployment, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CensusTract=" + String.valueOf(CensusTract));
			sb.append(",County=" + County);
			sb.append(",Borough=" + Borough);
			sb.append(",TotalPop=" + String.valueOf(TotalPop));
			sb.append(",Men=" + String.valueOf(Men));
			sb.append(",Women=" + String.valueOf(Women));
			sb.append(",Hispanic=" + String.valueOf(Hispanic));
			sb.append(",White=" + String.valueOf(White));
			sb.append(",Black=" + String.valueOf(Black));
			sb.append(",Native=" + String.valueOf(Native));
			sb.append(",Asian=" + String.valueOf(Asian));
			sb.append(",Citizen=" + String.valueOf(Citizen));
			sb.append(",Income=" + Income);
			sb.append(",IncomeErr=" + IncomeErr);
			sb.append(",IncomePerCap=" + String.valueOf(IncomePerCap));
			sb.append(",IncomePerCapErr=" + String.valueOf(IncomePerCapErr));
			sb.append(",Poverty=" + Poverty);
			sb.append(",ChildPoverty=" + ChildPoverty);
			sb.append(",Professional=" + Professional);
			sb.append(",Service=" + Service);
			sb.append(",Office=" + Office);
			sb.append(",Construction=" + Construction);
			sb.append(",Production=" + Production);
			sb.append(",Drive=" + Drive);
			sb.append(",Carpool=" + Carpool);
			sb.append(",Transit=" + Transit);
			sb.append(",Walk=" + Walk);
			sb.append(",OtherTransp=" + OtherTransp);
			sb.append(",WorkAtHome=" + WorkAtHome);
			sb.append(",MeanCommute=" + MeanCommute);
			sb.append(",Employed=" + String.valueOf(Employed));
			sb.append(",PrivateWork=" + PrivateWork);
			sb.append(",PublicWork=" + PublicWork);
			sb.append(",SelfEmployed=" + SelfEmployed);
			sb.append(",FamilyWork=" + FamilyWork);
			sb.append(",Unemployment=" + Unemployment);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputDelimited_5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tFileInputDelimited_6Process(globalMap);

				row7Struct row7 = new row7Struct();
				row7Struct row9 = row7;

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row9");
				}

				int tos_count_tMap_2 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) globalMap
						.get("tHash_Lookup_row10"));

				row10Struct row10HashKey = new row10Struct();
				row10Struct row10Default = new row10Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tLogRow_6 begin ] start
				 */

				ok_Hash.put("tLogRow_6", false);
				start_Hash.put("tLogRow_6", System.currentTimeMillis());

				currentComponent = "tLogRow_6";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row7");
				}

				int tos_count_tLogRow_6 = 0;

				/**
				 * [tLogRow_6 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_5 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_5", false);
				start_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_5";

				int tos_count_tFileInputDelimited_5 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_5 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_5 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_5 = null;
				int limit_tFileInputDelimited_5 = 200;
				try {

					Object filename_tFileInputDelimited_5 = "C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/CensusData.csv";
					if (filename_tFileInputDelimited_5 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_5 = 0, random_value_tFileInputDelimited_5 = -1;
						if (footer_value_tFileInputDelimited_5 > 0 || random_value_tFileInputDelimited_5 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_5 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/CensusData.csv",
								"US-ASCII", ",", "\n", false, 1, 0, limit_tFileInputDelimited_5, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_5 != null && fid_tFileInputDelimited_5.nextRecord()) {
						rowstate_tFileInputDelimited_5.reset();

						row7 = null;

						boolean whetherReject_tFileInputDelimited_5 = false;
						row7 = new row7Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_5 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_5 = 0;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.CensusTract = ParserUtils.parseTo_Long(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"CensusTract", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.CensusTract = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 1;

							row7.County = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 2;

							row7.Borough = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 3;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.TotalPop = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"TotalPop", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.TotalPop = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 4;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Men = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Men", "row7", temp, ex_tFileInputDelimited_5), ex_tFileInputDelimited_5));
								}

							} else {

								row7.Men = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 5;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Women = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Women", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Women = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 6;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Hispanic = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Hispanic", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Hispanic = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 7;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.White = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"White", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.White = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 8;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Black = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Black", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Black = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 9;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Native = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Native", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Native = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 10;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Asian = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Asian", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Asian = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 11;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Citizen = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Citizen", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Citizen = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 12;

							row7.Income = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 13;

							row7.IncomeErr = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 14;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.IncomePerCap = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"IncomePerCap", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.IncomePerCap = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 15;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.IncomePerCapErr = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"IncomePerCapErr", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.IncomePerCapErr = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 16;

							row7.Poverty = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 17;

							row7.ChildPoverty = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 18;

							row7.Professional = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 19;

							row7.Service = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 20;

							row7.Office = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 21;

							row7.Construction = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 22;

							row7.Production = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 23;

							row7.Drive = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 24;

							row7.Carpool = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 25;

							row7.Transit = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 26;

							row7.Walk = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 27;

							row7.OtherTransp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 28;

							row7.WorkAtHome = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 29;

							row7.MeanCommute = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 30;

							temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
							if (temp.length() > 0) {

								try {

									row7.Employed = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_5) {
									globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",
											ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"Employed", "row7", temp, ex_tFileInputDelimited_5),
											ex_tFileInputDelimited_5));
								}

							} else {

								row7.Employed = null;

							}

							columnIndexWithD_tFileInputDelimited_5 = 31;

							row7.PrivateWork = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 32;

							row7.PublicWork = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 33;

							row7.SelfEmployed = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 34;

							row7.FamilyWork = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							columnIndexWithD_tFileInputDelimited_5 = 35;

							row7.Unemployment = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);

							if (rowstate_tFileInputDelimited_5.getException() != null) {
								throw rowstate_tFileInputDelimited_5.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_5 = true;

							System.err.println(e.getMessage());
							row7 = null;

						}

						/**
						 * [tFileInputDelimited_5 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_5 main ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						tos_count_tFileInputDelimited_5++;

						/**
						 * [tFileInputDelimited_5 main ] stop
						 */

						/**
						 * [tFileInputDelimited_5 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						/**
						 * [tFileInputDelimited_5 process_data_begin ] stop
						 */
// Start of branch "row7"
						if (row7 != null) {

							/**
							 * [tLogRow_6 main ] start
							 */

							currentComponent = "tLogRow_6";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row7"

								);
							}

							row9 = row7;

							tos_count_tLogRow_6++;

							/**
							 * [tLogRow_6 main ] stop
							 */

							/**
							 * [tLogRow_6 process_data_begin ] start
							 */

							currentComponent = "tLogRow_6";

							/**
							 * [tLogRow_6 process_data_begin ] stop
							 */

							/**
							 * [tMap_2 main ] start
							 */

							currentComponent = "tMap_2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row9"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_2 = false;
							boolean mainRowRejected_tMap_2 = false;

							///////////////////////////////////////////////
							// Starting Lookup Table "row10"
							///////////////////////////////////////////////

							boolean forceLooprow10 = false;

							row10Struct row10ObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_2) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_2 = false;

								row10HashKey.County = row9.County;

								row10HashKey.hashCodeDirty = true;

								tHash_Lookup_row10.lookup(row10HashKey);

							} // G_TM_M_020

							if (tHash_Lookup_row10 != null && tHash_Lookup_row10.getCount(row10HashKey) > 1) { // G 071

								// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup
								// 'row10' and it contains more one result from keys : row10.County = '" +
								// row10HashKey.County + "'");
							} // G 071

							row10Struct row10 = null;

							row10Struct fromLookup_row10 = null;
							row10 = row10Default;

							if (tHash_Lookup_row10 != null && tHash_Lookup_row10.hasNext()) { // G 099

								fromLookup_row10 = tHash_Lookup_row10.next();

							} // G 099

							if (fromLookup_row10 != null) {
								row10 = fromLookup_row10;
							}

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
								// ###############################
								// # Output tables

// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_2 = false;

							tos_count_tMap_2++;

							/**
							 * [tMap_2 main ] stop
							 */

							/**
							 * [tMap_2 process_data_begin ] start
							 */

							currentComponent = "tMap_2";

							/**
							 * [tMap_2 process_data_begin ] stop
							 */

							/**
							 * [tMap_2 process_data_end ] start
							 */

							currentComponent = "tMap_2";

							/**
							 * [tMap_2 process_data_end ] stop
							 */

							/**
							 * [tLogRow_6 process_data_end ] start
							 */

							currentComponent = "tLogRow_6";

							/**
							 * [tLogRow_6 process_data_end ] stop
							 */

						} // End of branch "row7"

						/**
						 * [tFileInputDelimited_5 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_5";

						/**
						 * [tFileInputDelimited_5 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_5 end ] start
						 */

						currentComponent = "tFileInputDelimited_5";

					}
				} finally {
					if (!((Object) ("C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/CensusData.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_5 != null) {
							fid_tFileInputDelimited_5.close();
						}
					}
					if (fid_tFileInputDelimited_5 != null) {
						globalMap.put("tFileInputDelimited_5_NB_LINE", fid_tFileInputDelimited_5.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_5", true);
				end_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_5 end ] stop
				 */

				/**
				 * [tLogRow_6 end ] start
				 */

				currentComponent = "tLogRow_6";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row7");
				}

				ok_Hash.put("tLogRow_6", true);
				end_Hash.put("tLogRow_6", System.currentTimeMillis());

				/**
				 * [tLogRow_6 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row10 != null) {
					tHash_Lookup_row10.endGet();
				}
				globalMap.remove("tHash_Lookup_row10");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row9");
				}

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_2"
			globalMap.remove("tHash_Lookup_row10");

			try {

				/**
				 * [tFileInputDelimited_5 finally ] start
				 */

				currentComponent = "tFileInputDelimited_5";

				/**
				 * [tFileInputDelimited_5 finally ] stop
				 */

				/**
				 * [tLogRow_6 finally ] start
				 */

				currentComponent = "tLogRow_6";

				/**
				 * [tLogRow_6 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 1);
	}

	public static class row10Struct implements routines.system.IPersistableComparableLookupRow<row10Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Float Latitude;

		public Float getLatitude() {
			return this.Latitude;
		}

		public Double Longitude;

		public Double getLongitude() {
			return this.Longitude;
		}

		public Long BlockCode;

		public Long getBlockCode() {
			return this.BlockCode;
		}

		public String County;

		public String getCounty() {
			return this.County;
		}

		public String State;

		public String getState() {
			return this.State;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.County == null) ? 0 : this.County.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row10Struct other = (row10Struct) obj;

			if (this.County == null) {
				if (other.County != null)
					return false;

			} else if (!this.County.equals(other.County))

				return false;

			return true;
		}

		public void copyDataTo(row10Struct other) {

			other.Latitude = this.Latitude;
			other.Longitude = this.Longitude;
			other.BlockCode = this.BlockCode;
			other.County = this.County;
			other.State = this.State;

		}

		public void copyKeysDataTo(row10Struct other) {

			other.County = this.County;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.County = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					this.County = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.County, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.County, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				length = dis.readByte();
				if (length == -1) {
					this.Latitude = null;
				} else {
					this.Latitude = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.Longitude = null;
				} else {
					this.Longitude = dis.readDouble();
				}

				length = dis.readByte();
				if (length == -1) {
					this.BlockCode = null;
				} else {
					this.BlockCode = dis.readLong();
				}

				this.State = readString(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				length = objectIn.readByte();
				if (length == -1) {
					this.Latitude = null;
				} else {
					this.Latitude = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.Longitude = null;
				} else {
					this.Longitude = objectIn.readDouble();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.BlockCode = null;
				} else {
					this.BlockCode = objectIn.readLong();
				}

				this.State = readString(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Latitude);
				}

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				if (this.BlockCode == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.BlockCode);
				}

				writeString(this.State, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				if (this.Latitude == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.Latitude);
				}

				if (this.Longitude == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeDouble(this.Longitude);
				}

				if (this.BlockCode == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeLong(this.BlockCode);
				}

				writeString(this.State, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Latitude=" + String.valueOf(Latitude));
			sb.append(",Longitude=" + String.valueOf(Longitude));
			sb.append(",BlockCode=" + String.valueOf(BlockCode));
			sb.append(",County=" + County);
			sb.append(",State=" + State);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.County, other.County);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_PROJET_TALEND_2023_import_donnee = new byte[0];
		static byte[] commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[0];

		public Float Latitude;

		public Float getLatitude() {
			return this.Latitude;
		}

		public Double Longitude;

		public Double getLongitude() {
			return this.Longitude;
		}

		public Long BlockCode;

		public Long getBlockCode() {
			return this.BlockCode;
		}

		public String County;

		public String getCounty() {
			return this.County;
		}

		public String State;

		public String getState() {
			return this.State;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_TALEND_2023_import_donnee.length) {
					if (length < 1024 && commonByteArray_PROJET_TALEND_2023_import_donnee.length == 0) {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[1024];
					} else {
						commonByteArray_PROJET_TALEND_2023_import_donnee = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length);
				strReturn = new String(commonByteArray_PROJET_TALEND_2023_import_donnee, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.BlockCode = null;
					} else {
						this.BlockCode = dis.readLong();
					}

					this.County = readString(dis);

					this.State = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_TALEND_2023_import_donnee) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.BlockCode = null;
					} else {
						this.BlockCode = dis.readLong();
					}

					this.County = readString(dis);

					this.State = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Float

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// Long

				if (this.BlockCode == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.BlockCode);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.State, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Float

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// Long

				if (this.BlockCode == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.BlockCode);
				}

				// String

				writeString(this.County, dos);

				// String

				writeString(this.State, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Latitude=" + String.valueOf(Latitude));
			sb.append(",Longitude=" + String.valueOf(Longitude));
			sb.append(",BlockCode=" + String.valueOf(BlockCode));
			sb.append(",County=" + County);
			sb.append(",State=" + State);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row8Struct row8 = new row8Struct();
				row8Struct row10 = row8;

				/**
				 * [tAdvancedHash_row10 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row10", false);
				start_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row10";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row10");
				}

				int tos_count_tAdvancedHash_row10 = 0;

				// connection name:row10
				// source node:tLogRow_7 - inputs:(row8) outputs:(row10,row10) | target
				// node:tAdvancedHash_row10 - inputs:(row10) outputs:()
				// linked node: tMap_2 - inputs:(row9,row10) outputs:()

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row10 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row10Struct>getLookup(matchingModeEnum_row10);

				globalMap.put("tHash_Lookup_row10", tHash_Lookup_row10);

				/**
				 * [tAdvancedHash_row10 begin ] stop
				 */

				/**
				 * [tLogRow_7 begin ] start
				 */

				ok_Hash.put("tLogRow_7", false);
				start_Hash.put("tLogRow_7", System.currentTimeMillis());

				currentComponent = "tLogRow_7";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row8");
				}

				int tos_count_tLogRow_7 = 0;

				/**
				 * [tLogRow_7 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_6 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_6", false);
				start_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_6";

				int tos_count_tFileInputDelimited_6 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_6 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_6 = 0;
				int footer_tFileInputDelimited_6 = 0;
				int totalLinetFileInputDelimited_6 = 0;
				int limittFileInputDelimited_6 = 200;
				int lastLinetFileInputDelimited_6 = -1;

				char fieldSeparator_tFileInputDelimited_6[] = null;

				// support passing value (property: Field Separator) by 'context.fs' or
				// 'globalMap.get("fs")'.
				if (((String) ",").length() > 0) {
					fieldSeparator_tFileInputDelimited_6 = ((String) ",").toCharArray();
				} else {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_6[] = null;

				// support passing value (property: Row Separator) by 'context.rs' or
				// 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_6 = ((String) "\n").toCharArray();
				} else {
					throw new IllegalArgumentException("Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_6 = /** Start field tFileInputDelimited_6:FILENAME */
						"C:/Users/Cédric/OneDrive/Documents/Doc/Cours IUT/2A/Projet-20231114/CensusDataBlockLocation.csv"/**
																															 * End
																															 * field
																															 * tFileInputDelimited_6:FILENAME
																															 */
				;
				com.talend.csv.CSVReader csvReadertFileInputDelimited_6 = null;

				try {

					String[] rowtFileInputDelimited_6 = null;
					int currentLinetFileInputDelimited_6 = 0;
					int outputLinetFileInputDelimited_6 = 0;
					try {// TD110 begin
						if (filename_tFileInputDelimited_6 instanceof java.io.InputStream) {

							int footer_value_tFileInputDelimited_6 = 0;
							if (footer_value_tFileInputDelimited_6 > 0) {
								throw new java.lang.Exception(
										"When the input source is a stream,footer shouldn't be bigger than 0.");
							}

							csvReadertFileInputDelimited_6 = new com.talend.csv.CSVReader(
									(java.io.InputStream) filename_tFileInputDelimited_6,
									fieldSeparator_tFileInputDelimited_6[0], "US-ASCII");
						} else {
							csvReadertFileInputDelimited_6 = new com.talend.csv.CSVReader(
									String.valueOf(filename_tFileInputDelimited_6),
									fieldSeparator_tFileInputDelimited_6[0], "US-ASCII");
						}

						csvReadertFileInputDelimited_6.setTrimWhitespace(false);
						if ((rowSeparator_tFileInputDelimited_6[0] != '\n')
								&& (rowSeparator_tFileInputDelimited_6[0] != '\r'))
							csvReadertFileInputDelimited_6.setLineEnd("" + rowSeparator_tFileInputDelimited_6[0]);

						csvReadertFileInputDelimited_6.setQuoteChar('"');

						csvReadertFileInputDelimited_6.setEscapeChar(csvReadertFileInputDelimited_6.getQuoteChar());

						if (footer_tFileInputDelimited_6 > 0) {
							for (totalLinetFileInputDelimited_6 = 0; totalLinetFileInputDelimited_6 < 1; totalLinetFileInputDelimited_6++) {
								csvReadertFileInputDelimited_6.readNext();
							}
							csvReadertFileInputDelimited_6.setSkipEmptyRecords(false);
							while (csvReadertFileInputDelimited_6.readNext()) {

								totalLinetFileInputDelimited_6++;

							}
							int lastLineTemptFileInputDelimited_6 = totalLinetFileInputDelimited_6
									- footer_tFileInputDelimited_6 < 0 ? 0
											: totalLinetFileInputDelimited_6 - footer_tFileInputDelimited_6;
							if (lastLinetFileInputDelimited_6 > 0) {
								lastLinetFileInputDelimited_6 = lastLinetFileInputDelimited_6 < lastLineTemptFileInputDelimited_6
										? lastLinetFileInputDelimited_6
										: lastLineTemptFileInputDelimited_6;
							} else {
								lastLinetFileInputDelimited_6 = lastLineTemptFileInputDelimited_6;
							}

							csvReadertFileInputDelimited_6.close();
							if (filename_tFileInputDelimited_6 instanceof java.io.InputStream) {
								csvReadertFileInputDelimited_6 = new com.talend.csv.CSVReader(
										(java.io.InputStream) filename_tFileInputDelimited_6,
										fieldSeparator_tFileInputDelimited_6[0], "US-ASCII");
							} else {
								csvReadertFileInputDelimited_6 = new com.talend.csv.CSVReader(
										String.valueOf(filename_tFileInputDelimited_6),
										fieldSeparator_tFileInputDelimited_6[0], "US-ASCII");
							}
							csvReadertFileInputDelimited_6.setTrimWhitespace(false);
							if ((rowSeparator_tFileInputDelimited_6[0] != '\n')
									&& (rowSeparator_tFileInputDelimited_6[0] != '\r'))
								csvReadertFileInputDelimited_6.setLineEnd("" + rowSeparator_tFileInputDelimited_6[0]);

							csvReadertFileInputDelimited_6.setQuoteChar('"');

							csvReadertFileInputDelimited_6.setEscapeChar(csvReadertFileInputDelimited_6.getQuoteChar());

						}

						if (limittFileInputDelimited_6 != 0) {
							for (currentLinetFileInputDelimited_6 = 0; currentLinetFileInputDelimited_6 < 1; currentLinetFileInputDelimited_6++) {
								csvReadertFileInputDelimited_6.readNext();
							}
						}
						csvReadertFileInputDelimited_6.setSkipEmptyRecords(false);

					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					} // TD110 end

					while (limittFileInputDelimited_6 != 0 && csvReadertFileInputDelimited_6 != null
							&& csvReadertFileInputDelimited_6.readNext()) {
						rowstate_tFileInputDelimited_6.reset();

						rowtFileInputDelimited_6 = csvReadertFileInputDelimited_6.getValues();

						currentLinetFileInputDelimited_6++;

						if (lastLinetFileInputDelimited_6 > -1
								&& currentLinetFileInputDelimited_6 > lastLinetFileInputDelimited_6) {
							break;
						}
						outputLinetFileInputDelimited_6++;
						if (limittFileInputDelimited_6 > 0
								&& outputLinetFileInputDelimited_6 > limittFileInputDelimited_6) {
							break;
						}

						row8 = null;

						boolean whetherReject_tFileInputDelimited_6 = false;
						row8 = new row8Struct();
						try {

							char fieldSeparator_tFileInputDelimited_6_ListType[] = null;
							// support passing value (property: Field Separator) by 'context.fs' or
							// 'globalMap.get("fs")'.
							if (((String) ",").length() > 0) {
								fieldSeparator_tFileInputDelimited_6_ListType = ((String) ",").toCharArray();
							} else {
								throw new IllegalArgumentException("Field Separator must be assigned a char.");
							}
							if (rowtFileInputDelimited_6.length == 1 && ("\015").equals(rowtFileInputDelimited_6[0])) {// empty
																														// line
																														// when
																														// row
																														// separator
																														// is
																														// '\n'

								row8.Latitude = null;

								row8.Longitude = null;

								row8.BlockCode = null;

								row8.County = null;

								row8.State = null;

							} else {

								int columnIndexWithD_tFileInputDelimited_6 = 0; // Column Index

								columnIndexWithD_tFileInputDelimited_6 = 0;

								if (columnIndexWithD_tFileInputDelimited_6 < rowtFileInputDelimited_6.length) {

									if (rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6].length() > 0) {
										try {

											row8.Latitude = ParserUtils.parseTo_Float(
													rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6]);

										} catch (java.lang.Exception ex_tFileInputDelimited_6) {
											globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
													ex_tFileInputDelimited_6.getMessage());
											rowstate_tFileInputDelimited_6.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"Latitude", "row8",
															rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6],
															ex_tFileInputDelimited_6),
													ex_tFileInputDelimited_6));
										}
									} else {

										row8.Latitude = null;

									}

								} else {

									row8.Latitude = null;

								}

								columnIndexWithD_tFileInputDelimited_6 = 1;

								if (columnIndexWithD_tFileInputDelimited_6 < rowtFileInputDelimited_6.length) {

									if (rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6].length() > 0) {
										try {

											row8.Longitude = ParserUtils.parseTo_Double(
													rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6]);

										} catch (java.lang.Exception ex_tFileInputDelimited_6) {
											globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
													ex_tFileInputDelimited_6.getMessage());
											rowstate_tFileInputDelimited_6.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"Longitude", "row8",
															rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6],
															ex_tFileInputDelimited_6),
													ex_tFileInputDelimited_6));
										}
									} else {

										row8.Longitude = null;

									}

								} else {

									row8.Longitude = null;

								}

								columnIndexWithD_tFileInputDelimited_6 = 2;

								if (columnIndexWithD_tFileInputDelimited_6 < rowtFileInputDelimited_6.length) {

									if (rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6].length() > 0) {
										try {

											row8.BlockCode = ParserUtils.parseTo_Long(
													rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6]);

										} catch (java.lang.Exception ex_tFileInputDelimited_6) {
											globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",
													ex_tFileInputDelimited_6.getMessage());
											rowstate_tFileInputDelimited_6.setException(new RuntimeException(String
													.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
															"BlockCode", "row8",
															rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6],
															ex_tFileInputDelimited_6),
													ex_tFileInputDelimited_6));
										}
									} else {

										row8.BlockCode = null;

									}

								} else {

									row8.BlockCode = null;

								}

								columnIndexWithD_tFileInputDelimited_6 = 3;

								if (columnIndexWithD_tFileInputDelimited_6 < rowtFileInputDelimited_6.length) {

									row8.County = rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6];

								} else {

									row8.County = null;

								}

								columnIndexWithD_tFileInputDelimited_6 = 4;

								if (columnIndexWithD_tFileInputDelimited_6 < rowtFileInputDelimited_6.length) {

									row8.State = rowtFileInputDelimited_6[columnIndexWithD_tFileInputDelimited_6];

								} else {

									row8.State = null;

								}

							}

							if (rowstate_tFileInputDelimited_6.getException() != null) {
								throw rowstate_tFileInputDelimited_6.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_6 = true;

							System.err.println(e.getMessage());
							row8 = null;

							globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE", e.getMessage());

						}

						/**
						 * [tFileInputDelimited_6 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_6 main ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						tos_count_tFileInputDelimited_6++;

						/**
						 * [tFileInputDelimited_6 main ] stop
						 */

						/**
						 * [tFileInputDelimited_6 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						/**
						 * [tFileInputDelimited_6 process_data_begin ] stop
						 */
// Start of branch "row8"
						if (row8 != null) {

							/**
							 * [tLogRow_7 main ] start
							 */

							currentComponent = "tLogRow_7";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row8"

								);
							}

							row10 = row8;

							tos_count_tLogRow_7++;

							/**
							 * [tLogRow_7 main ] stop
							 */

							/**
							 * [tLogRow_7 process_data_begin ] start
							 */

							currentComponent = "tLogRow_7";

							/**
							 * [tLogRow_7 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row10 main ] start
							 */

							currentComponent = "tAdvancedHash_row10";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row10"

								);
							}

							row10Struct row10_HashRow = new row10Struct();

							row10_HashRow.Latitude = row10.Latitude;

							row10_HashRow.Longitude = row10.Longitude;

							row10_HashRow.BlockCode = row10.BlockCode;

							row10_HashRow.County = row10.County;

							row10_HashRow.State = row10.State;

							tHash_Lookup_row10.put(row10_HashRow);

							tos_count_tAdvancedHash_row10++;

							/**
							 * [tAdvancedHash_row10 main ] stop
							 */

							/**
							 * [tAdvancedHash_row10 process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_row10";

							/**
							 * [tAdvancedHash_row10 process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_row10 process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_row10";

							/**
							 * [tAdvancedHash_row10 process_data_end ] stop
							 */

							/**
							 * [tLogRow_7 process_data_end ] start
							 */

							currentComponent = "tLogRow_7";

							/**
							 * [tLogRow_7 process_data_end ] stop
							 */

						} // End of branch "row8"

						/**
						 * [tFileInputDelimited_6 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						/**
						 * [tFileInputDelimited_6 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_6 end ] start
						 */

						currentComponent = "tFileInputDelimited_6";

						nb_line_tFileInputDelimited_6++;
					}

				} finally {
					if (!(filename_tFileInputDelimited_6 instanceof java.io.InputStream)) {
						if (csvReadertFileInputDelimited_6 != null) {
							csvReadertFileInputDelimited_6.close();
						}
					}
					if (csvReadertFileInputDelimited_6 != null) {
						globalMap.put("tFileInputDelimited_6_NB_LINE", nb_line_tFileInputDelimited_6);
					}

				}

				ok_Hash.put("tFileInputDelimited_6", true);
				end_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_6 end ] stop
				 */

				/**
				 * [tLogRow_7 end ] start
				 */

				currentComponent = "tLogRow_7";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row8");
				}

				ok_Hash.put("tLogRow_7", true);
				end_Hash.put("tLogRow_7", System.currentTimeMillis());

				/**
				 * [tLogRow_7 end ] stop
				 */

				/**
				 * [tAdvancedHash_row10 end ] start
				 */

				currentComponent = "tAdvancedHash_row10";

				tHash_Lookup_row10.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row10");
				}

				ok_Hash.put("tAdvancedHash_row10", true);
				end_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row10 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_6 finally ] start
				 */

				currentComponent = "tFileInputDelimited_6";

				/**
				 * [tFileInputDelimited_6 finally ] stop
				 */

				/**
				 * [tLogRow_7 finally ] start
				 */

				currentComponent = "tLogRow_7";

				/**
				 * [tLogRow_7 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row10 finally ] start
				 */

				currentComponent = "tAdvancedHash_row10";

				/**
				 * [tAdvancedHash_row10 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final import_donnee import_donneeClass = new import_donnee();

		int exitCode = import_donneeClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = import_donnee.class.getClassLoader()
					.getResourceAsStream("projet_talend_2023/import_donnee_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = import_donnee.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_3Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_3) {
			globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_3.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_4Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_4) {
			globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_4.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_5Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_5) {
			globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_5.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out
					.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : import_donnee");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 373035 characters generated by Talend Open Studio for Data Integration on the
 * 16 novembre 2023 à 11:47:45 CET
 ************************************************************************************************/